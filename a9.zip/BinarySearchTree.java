/* CS 314 STUDENTS: FILL IN THIS HEADER.
 *
 * Student information for assignment:
 *
 *  On my honor, Nathaniel, this programming assignment is my own work
 *  and I have not provided this code to any other student.
 *
 *  UTEID: nl9656
 *  email address: nathaniel.li@utexas.edu
 *  TA name: Pranav
 *  Number of slip days I am using: 2
 */

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * Shell for a binary search tree class.
 * @author scottm
 * @param <E> The data type of the elements of this BinarySearchTree.
 * Must implement Comparable or inherit from a class that implements
 * Comparable.
 *
 */
public class BinarySearchTree<E extends Comparable<? super E>> {

    private BSTNode<E> root;
    // CS314 students. Add any other instance variables you want here
    private int size;

    // CS314 students. Add a default constructor here if you feel it is necessary.

    /**
     *  Add the specified item to this Binary Search Tree if it is not already present.
     *  <br>
     *  pre: <tt>value</tt> != null<br>
     *  post: Add value to this tree if not already present. Return true if this tree
     *  changed as a result of this method call, false otherwise.
     *  @param value the value to add to the tree
     *  @return false if an item equivalent to value is already present
     *  in the tree, return true if value is added to the tree and size() = old size() + 1
     */
    public boolean add(E value) {
        // keep track of the old side
        int oldSize = size;
        // recurse
        root = addHelper(root, value);
        // return if we added or not
        return size != oldSize;
    }

    // add helper to recurse
    private BSTNode<E> addHelper(BSTNode<E> n, E val) {
        // check if null
        if(n == null) {
            ++size;
            return new BSTNode<>(val);
        }
        int dir = val.compareTo(n.data);
        if(dir < 0) {
            n.left = addHelper(n.left, val);
        } else if(dir > 0) {
            n.right = addHelper(n.right, val);
        }
        return n;
    }

    /**
     *  Remove a specified item from this Binary Search Tree if it is present.
     *  <br>
     *  pre: <tt>value</tt> != null<br>
     *  post: Remove value from the tree if present, return true if this tree
     *  changed as a result of this method call, false otherwise.
     *  @param value the value to remove from the tree if present
     *  @return false if value was not present
     *  returns true if value was present and size() = old size() - 1
     */
    public boolean remove(E value) {
        int oldSize = size;
        root = removeHelper(root, value);
        return size != oldSize;
    }

    // remove helper to recurse
    private BSTNode<E> removeHelper(BSTNode<E> n, E val) {
        // check if null
        if(n == null) {
            return null;
        }
        // find the direction
        int dir = val.compareTo(n.data);
        if(dir < 0) {
            n.left = removeHelper(n.left, val);
        } else if(dir > 0) {
            n.right = removeHelper(n.right, val);
        // found it, so now remove
        } else {
            // 2 children
            if(n.left != null && n.right != null) {
                BSTNode<E> parent = n;
                BSTNode<E> pred = parent.left;
                while(pred.right != null) {
                    parent = pred;
                    pred = parent.right;
                }
                n.data = pred.data;
                if(n.equals(parent)) {
                    parent.left = removeHelper(pred, pred.data);
                } else {
                    parent.right = removeHelper(pred, pred.data);
                }
                return n;
            // 1 children
            } else if(n.left != null) {
                // update size
                --size;
                return n.left;
            } else if(n.right != null) {
                // update size
                --size;
                return n.right;
            // no children
            } else {
                // update size
                --size;
                return null;
            }
        }
        // making no changes
        return n;
    }


    /**
     *  Check to see if the specified element is in this Binary Search Tree.
     *  <br>
     *  pre: <tt>value</tt> != null<br>
     *  post: return true if value is present in tree, false otherwise
     *  @param value the value to look for in the tree
     *  @return true if value is present in this tree, false otherwise
     */
    public boolean isPresent(E value) {
        return isPresentHelper(root, value);
    }

    // add helper to recurse
    private boolean isPresentHelper(BSTNode<E> n, E val) {
        // check if null (base case)
        if(n == null) {
            return false;
        }
        // see which direction to go
        int dir = val.compareTo(n.data);
        if(dir < 0) {
            return isPresentHelper(n.left, val);
        } else if(dir > 0) {
            return isPresentHelper(n.right, val);
        } else {
            // if we found it, then it's here
            return true;
        }
    }



    /**
     *  Return how many elements are in this Binary Search Tree.
     *  <br>
     *  pre: none<br>
     *  post: return the number of items in this tree
     *  @return the number of items in this Binary Search Tree
     */
    public int size() {
        return size;
    }

    /**
     *  return the height of this Binary Search Tree.
     *  <br>
     *  pre: none<br>
     *  post: return the height of this tree.
     *  If the tree is empty return -1, otherwise return the
     *  height of the tree
     *  @return the height of this tree or -1 if the tree is empty
     */
    public int height() {
        return heightHelper(root);
    }

    // add helper to recurse
    private int heightHelper(BSTNode<E> n) {
        // check if null
        if(n == null) {
            return -1;
        }
        return Math.max(heightHelper(n.left), heightHelper(n.right)) + 1;
    }

    /**
     *  Return a list of all the elements in this Binary Search Tree.
     *  <br>
     *  pre: none<br>
     *  post: return a List object with all data from the tree in ascending order.
     *  If the tree is empty return an empty List
     *  @return a List object with all data from the tree in sorted order
     *  if the tree is empty return an empty List
     */
    public List<E> getAll() {
        List<E> ret = new ArrayList<>();
        getAllHelper(root, ret);
        return ret;
    }

    // getAll helper to recurse
    private void getAllHelper(BSTNode<E> n, List<E> ret) {
        // check if null
        if(n != null) {
            // in order traversal
            getAllHelper(n.left, ret);
            ret.add(n.data);
            getAllHelper(n.right, ret);
        }
    }


    /**
     * return the maximum value in this binary search tree.
     * <br>
     * pre: <tt>size()</tt> > 0<br>
     * post: return the largest value in this Binary Search Tree
     * @return the maximum value in this tree
     */
    public E max() {
        return maxHelper(root);
    }

    // add helper to recurse
    private E maxHelper(BSTNode<E> n) {
        // check if null
        if(n.right != null) {
            return maxHelper(n.right);
        }
        // return when we can't go right anymore
        return n.data;
    }

    /**
     * return the minimum value in this binary search tree.
     * <br>
     * pre: <tt>size()</tt> > 0<br>
     * post: return the smallest value in this Binary Search Tree
     * @return the minimum value in this tree
     */
    public E min() {
        return minHelper(root);
    }

    // add helper to recurse
    private E minHelper(BSTNode<E> n) {
        // check if null
        if(n.left != null) {
            return minHelper(n.left);
        }
        // return when we can't go left anymore
        return n.data;
    }

    /**
     * An add method that implements the add algorithm iteratively 
     * instead of recursively.
     * <br>pre: data != null
     * <br>post: if data is not present add it to the tree, 
     * otherwise do nothing.
     * @param data the item to be added to this tree
     * @return true if data was not present before this call to add, 
     * false otherwise.
     */
    public boolean iterativeAdd(E data) {
        // make pointer
        BSTNode<E> current = root;
        // loop iteratively
        while(true) {
            int dir = data.compareTo(current.data);
            // if left
            if(dir < 0) {
                // add if no more left
                if(current.left == null) {
                    BSTNode<E> temp = new BSTNode<>(data);
                    current.left = temp;
                    ++size;
                    return true;
                }
                // "iterate"
                current = current.left;
            // if right
            } else if(dir > 0) {
                // add if no more right
                if(current.right == null) {
                    BSTNode<E> temp = new BSTNode<>(data);
                    current.right = temp;
                    ++size;
                    return true;
                }
                // "iterate"
                current = current.right;
            } else {
                return false;
            }
        }
    }


    /**
     * Return the "kth" element in this Binary Search Tree. If kth = 0 the
     * smallest value (minimum) is returned.
     * If kth = 1 the second smallest value is returned, and so forth.
     * <br>pre: 0 <= kth < size()
     * @param kth indicates the rank of the element to get
     * @return the kth value in this Binary Search Tree
     */

    // keep track of the index globally
    private static int index;
    public E get(int kth) {
        index = kth;
        return getHelper(root);
    }
    private E getHelper(BSTNode<E> n) {
        // check if null
        if(n != null) {
            // recurse in order
            E var = getHelper(n.left);
            if(var != null) {
                return var;
            }
            // we found the element at the index
            if(index == 0) {
                return n.data;
            }
            --index;
            // recurse in order
            var = getHelper(n.right);
            return var;
        }
        return null;
    }


    /**
     * Return a List with all values in this Binary Search Tree 
     * that are less than the parameter <tt>value</tt>.
     * <tt>value</tt> != null<br>
     * @param value the cutoff value
     * @return a List with all values in this tree that are less than 
     * the parameter value. If there are no values in this tree less 
     * than value return an empty list. The elements of the list are 
     * in ascending order.
     */
    public List<E> getAllLessThan(E value) {
        // create return var
        List<E> ret = new ArrayList<>();
        allLessHelper(root, ret, value);
        return ret;
    }

    // add helper to recurse
    private void allLessHelper(BSTNode<E> n, List<E> ret, E value) {
        // check if null
        if(n != null) {
            // in order for only elements less
            allLessHelper(n.left, ret, value);
            if(n.data.compareTo(value) < 0) {
                ret.add(n.data);
            }
            if(n.data.compareTo(value) < 0) {
                allLessHelper(n.right, ret, value);
            }
        }
    }


    /**
     * Return a List with all values in this Binary Search Tree 
     * that are greater than the parameter <tt>value</tt>.
     * <tt>value</tt> != null<br>
     * @param value the cutoff value
     * @return a List with all values in this tree that are greater
     *  than the parameter value. If there are no values in this tree
     * greater than value return an empty list. 
     * The elements of the list are in ascending order.
     */
    public List<E> getAllGreaterThan(E value) {
        // create return var
        List<E> ret = new ArrayList<>();
        allGreaterHelper(root, ret, value);
        // reverse then return it
        Collections.reverse(ret);
        return ret;
    }

    // add helper to recurse
    private void allGreaterHelper(BSTNode<E> n, List<E> ret, E value) {
        // check if null
        if(n != null) {
            // in order for only elements greater
            allGreaterHelper(n.right, ret, value);
            if(n.data.compareTo(value) > 0) {
                ret.add(n.data);
            }
            if(n.data.compareTo(value) > 0) {
                allGreaterHelper(n.left, ret, value);
            }
        }
    }


    /**
     * Find the number of nodes in this tree at the specified depth.
     * <br>pre: none
     * @param d The target depth.
     * @return The number of nodes in this tree at a depth equal to
     * the parameter d.
     */
    public int numNodesAtDepth(int d) {
        return nodesAtDepthHelper(root, d);
    }

    // add helper to recurse
    private int nodesAtDepthHelper(BSTNode<E> n, int depth) {
        // check if null
        if(n != null) {
            // if we have reached the depth then add 1
            if(depth == 0) {
                return 1;
            }
            // return all of the counts
            return nodesAtDepthHelper(n.left, depth - 1) + nodesAtDepthHelper(n.right, depth - 1);
        }
        // we aren't at the right depth
        return 0;
    }


    /**
     * Prints a vertical representation of this tree.
     * The tree has been rotated counter clockwise 90
     * degrees. The root is on the left. Each node is printed
     * out on its own row. A node's children will not necessarily
     * be at the rows directly above and below a row. They will
     * be indented three spaces from the parent. Nodes indented the
     * same amount are at the same depth.
     * <br>pre: none
     */
    public void printTree() {
        printTree(root, "");
    }

    private void printTree(BSTNode<E> n, String spaces) {
        if(n != null){
            printTree(n.getRight(), spaces + "  ");
            System.out.println(spaces + n.getData());
            printTree(n.getLeft(), spaces + "  ");
        }
    }

    private static class BSTNode<E extends Comparable<? super E>> {
        private E data;
        private BSTNode<E> left;
        private BSTNode<E> right;

        public BSTNode() {
            this(null);
        }

        public BSTNode(E initValue) {
            this(null, initValue, null);
        }

        public BSTNode(BSTNode<E> initLeft,
                E initValue,
                BSTNode<E> initRight) {
            data = initValue;
            left = initLeft;
            right = initRight;
        }

        public E getData() {
            return data;
        }

        public BSTNode<E> getLeft() {
            return left;
        }

        public BSTNode<E> getRight() {
            return right;
        }

        public void setData(E theNewValue) {
            data = theNewValue;
        }

        public void setLeft(BSTNode<E> theNewLeft) {
            left = theNewLeft;
        }

        public void setRight(BSTNode<E> theNewRight) {
            right = theNewRight;
        }
    }
}
