/* CS 314 STUDENTS: FILL IN THIS HEADER.
 *
 * Student information for assignment:
 *
 *  On my honor, Nathaniel, this programming assignment is my own work
 *  and I have not provided this code to any other student.
 *
 *  UTEID: nl9656
 *  email address: nathaniel.li@utexas.edu
 *  TA name: Pranav
 *  Number of slip days I am using: 2
 */


import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Random;

/**
 * Some test cases for CS314 Binary Search Tree assignment.
 *
 */
public class BSTTester {

    /**
     * The main method runs the tests.
     * @param args Not used
     */
    public static void main(String[] args) {
        BinarySearchTree<Integer> t = new BinarySearchTree<>();

        //test 1
        System.out.println("add 1");
        t.add(1);
        showTestResults(t.size() == 1, 1);

        //test 2
        System.out.println("add 2");
        t.add(2);
        showTestResults(t.size() == 2, 2);

        //test 3
        System.out.println("remove 1");
        t.remove(1);
        showTestResults(t.size() == 1, 3);

        //test 4
        System.out.println("remove 2");
        t.remove(1);
        showTestResults(t.height() == 0, 4);

        //test 5
        System.out.println("isPresent 1");
        showTestResults(!t.isPresent(1), 5);

        //test 6
        System.out.println("isPresent 2");
        showTestResults(!t.isPresent(0), 6);

        //test 7
        System.out.println("size 1");
        showTestResults(t.size() == 1, 7);

        //test 8
        System.out.println("size 2");
        t.add(3);
        showTestResults(t.size() == 2, 8);

        //test 9
        System.out.println("height 1");
        showTestResults(t.height() == 1, 9);

        //test 10
        System.out.println("height 2");
        t.remove(3);
        showTestResults(t.height() == 0, 10);

        //test 11
        System.out.println("getAll 1");
        List<Integer> temp = t.getAll();
        showTestResults(temp.size() == 1, 311);

        //test 12
        System.out.println("getAll 2");
        showTestResults(temp.get(0) == 2, 12);

        //test 13
        System.out.println("max 1");
        showTestResults(t.max() == 2, 13);

        //test 14
        System.out.println("max 2");
        t.add(4);
        showTestResults(t.max() == 4, 14);

        //test 15
        System.out.println("min 1");
        t.add(2);
        showTestResults(t.min() == 2, 15);

        //test 16
        System.out.println("min 2");
        t.remove(1);
        showTestResults(t.min() == 2, 16);

        //test 17
        System.out.println("iterativeAdd 1");
        t.iterativeAdd(3);
        showTestResults(t.size() == 3, 17);

        //test 18
        System.out.println("iterativeAdd 2");
        t.iterativeAdd(1);
        showTestResults(t.min() == 1, 18);

        //test 19
        System.out.println("get 1");
        int temp2 = t.get(2);
        showTestResults(temp2 == 3, 19);

        //test 20
        System.out.println("get 2");
        temp2 = t.get(3);
        showTestResults(temp2 == 4, 20);

        //test 21
        System.out.println("getAllLessThan 1");
        temp = t.getAllLessThan(2);
        showTestResults(temp.size() == 1, 21);

        //test 22
        System.out.println("getAllLessThan 2");
        temp = t.getAllLessThan(4);
        showTestResults(temp.get(2) == 3, 22);

        //test 23
        System.out.println("getAllGreaterThan 1");
        temp = t.getAllGreaterThan(2);
        showTestResults(temp.size() == 2, 23);

        //test 24
        System.out.println("getAllGreaterThan 2");
        temp = t.getAllGreaterThan(1);
        showTestResults(temp.get(2) == 4, 24);

        //test 25
        System.out.println("numNodesAtDepth 1");
        showTestResults(t.numNodesAtDepth(1) == 2, 25);

        //test 26
        System.out.println("numNodesAtDepth 2");
        showTestResults(t.numNodesAtDepth(2) == 1, 26);

    }

    private static void showTestResults(boolean passed, int testNum) {
        if (passed) {
            System.out.println("Test " + testNum + " passed.");
        } else {
            System.out.println("TEST " + testNum + " FAILED.");
        }
        System.out.println();
    }
}
