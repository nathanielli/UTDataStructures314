/*  Student information for assignment:
 *
 *  On OUR honor, Nathaniel and Adithya,
 *  this programming assignment is OUR own work
 *  and WE have not provided this code to any other student.
 *
 *  Number of slip days used: 0
 *
 *  Student 1 (Student whose Canvas account is being used)
 *  UTEID: aa86362
 *  email address: adithya.arunganesh@utexas.edu
 *  Grader name: Pranav
 *  Section number: 50860
 *
 *  Student 2
 *  UTEID: nl9656
 *  email address: nathaniel.li@utexas.edu
 *
 */


//imports

import java.util.ArrayList;
import java.awt.Graphics;
import java.awt.Color;
import java.util.Arrays;

/**
 * Various recursive methods to be implemented.
 * Given shell file for CS314 assignment.
 */
public class Recursive {

    /**
     * Problem 1: convert a base 10 int to binary recursively.
     *   <br>pre: n != Integer.MIN_VALUE<br>
     *   <br>post: Returns a String that represents N in binary.
     *   All chars in returned String are '1's or '0's.
     *   Most significant digit is at position 0
     *   @param n the base 10 int to convert to base 2
     *   @return a String that is a binary representation of the parameter n
     */
    public static String getBinary(int n) {
        if (n == Integer.MIN_VALUE) {
            throw new IllegalArgumentException("Failed precondition: "
                    + "getBinary. n cannot equal "
                    + "Integer.MIN_VALUE. n: " + n);
        }
        // base case if n is 1
        if(n == 1) {
            return "1";
        // or its negative counterpart
        } else if(n == -1) {
            return "-1";
        // or for the edgecase 0
        } else if(n == 0) {
            return "0";
        }
        // recursive step
        return getBinary(n/2) + "" + Math.abs(n%2);
    }


    /**
     * Problem 2: reverse a String recursively.<br>
     *   pre: stringToRev != null<br>
     *   post: returns a String that is the reverse of stringToRev
     *   @param stringToRev the String to reverse.
     *   @return a String with the characters in stringToRev
     *   in reverse order.
     */
    public static String revString(String stringToRev) {
        if (stringToRev == null) {
            throw new IllegalArgumentException("Failed precondition: "
                    + "revString. parameter may not be null.");
        }
        // base case is if only last character left
        if(stringToRev.length() == 1) {
            return stringToRev.substring(stringToRev.length() - 1);
        }
        // recursive step
        return stringToRev.substring(stringToRev.length() - 1) + revString(stringToRev.substring(0, stringToRev.length() - 1));
    }


    /**
     * Problem 3: Returns the number of elements in data
     * that are followed directly by value that is
     * double that element.
     * pre: data != null
     * post: return the number of elements in data
     * that are followed immediately by double the value
     * @param data The array to search.
     * @return The number of elements in data that
     * are followed immediately by a value that is double the element.
     */
    public static int nextIsDouble(int[] data) {
        if (data == null) {
            throw new IllegalArgumentException("Failed precondition: "
                    + "revString. parameter may not be null.");
        }
        // check if there are less than 2 elements
        if (data.length < 2) {
            return 0;
        }

        // call recursion
        return nextIsDoubleHelper(data, 0);
    }


    // CS314 students, add your nextIsDouble helper method here
    public static int nextIsDoubleHelper(int[] data, int i) {
        // base case
        if(i == data.length - 1) {
            return 0;
        }

        // recursive step
        if(data[i] * 2 == data[++i]) {
            // add 1 to our count
            return 1 + nextIsDoubleHelper(data, i);
        } else {
            return 0 + nextIsDoubleHelper(data, i);
        }
    }

    /**  Problem 4: Find all combinations of mnemonics
     * for the given number.<br>
     *   pre: number != null, number.length() > 0,
     *   all characters in number are digits<br>
     *   post: see tips section of assignment handout
     *   @param number The number to find mnemonics for
     *   @return An ArrayList<String> with all possible mnemonics
     *   for the given number
     */
    public static ArrayList<String> listMnemonics(String number) {
        if (number == null ||  number.length() == 0 || !allDigits(number)) {
            throw new IllegalArgumentException("Failed precondition: "
                    + "listMnemonics");
        }

        ArrayList<String> result = new ArrayList<>();
        recursiveMnemonics(result, "", number);
        return result;
    }


    /*
     * Helper method for listMnemonics
     * mnemonics stores completed mnemonics
     * mneominicSoFar is a partial (possibly complete) mnemonic
     * digitsLeft are the digits that have not been used
     * from the original number.
     */
    private static void recursiveMnemonics(ArrayList<String> mnemonics,
                    String mnemonicSoFar, String digitsLeft) {

        // CS314 students, complete this method
        // base case is if there is only 1 more digit, we convert that digit and stop
        String letters = digitLetters(digitsLeft.charAt(0));
        if (digitsLeft.length() == 1) {
            for(int i = 0; i < letters.length(); ++i) {
                mnemonics.add(mnemonicSoFar + letters.charAt(i));
            }
            return;
        }

        digitsLeft = digitsLeft.substring(1);
        // recursive step
        for(int i = 0; i < letters.length(); ++i) {
            recursiveMnemonics(mnemonics, mnemonicSoFar + letters.charAt(i), digitsLeft);
        }
    }


    // used by method digitLetters
    private static final String[] letters = {"0", "1", "ABC",
            "DEF", "GHI", "JKL", "MNO", "PQRS", "TUV", "WXYZ"};


    /* helper method for recursiveMnemonics
     * pre: ch is a digit '0' through '9'
     * post: return the characters associated with
     * this digit on a phone keypad
     */
    private static String digitLetters(char ch) {
        if (ch < '0' || ch > '9') {
            throw new IllegalArgumentException("parameter "
                    + "ch must be a digit, 0 to 9. Given value = " + ch);
        }
        int index = ch - '0';
        return letters[index];
    }


    /* helper method for listMnemonics
     * pre: s != null
     * post: return true if every character in s is
     * a digit ('0' through '9')
     */
    private static boolean allDigits(String s) {
        if (s == null) {
            throw new IllegalArgumentException("Failed precondition: "
                    + "allDigits. String s cannot be null.");
        }
        boolean allDigits = true;
        int i = 0;
        while (i < s.length() && allDigits) {
            allDigits = s.charAt(i) >= '0' && s.charAt(i) <= '9';
            i++;
        }
        return allDigits;
    }


    /**
     * Problem 5: Draw a Sierpinski Carpet.
     * @param size the size in pixels of the window
     * @param limit the smallest size of a square in the carpet.
     */
    public static void drawCarpet(int size, int limit) {
        DrawingPanel p = new DrawingPanel(size, size);
        Graphics g = p.getGraphics();
        g.setColor(Color.BLACK);
        g.fillRect(0,0,size,size);
        g.setColor(Color.WHITE);
        drawSquares(g, size, limit, 0, 0);
    }


    /* Helper method for drawCarpet
     * Draw the individual squares of the carpet.
     * @param g The Graphics object to use to fill rectangles
     * @param size the size of the current square
     * @param limit the smallest allowable size of squares
     * @param x the x coordinate of the upper left corner of the current square
     * @param y the y coordinate of the upper left corner of the current square
     */
    private static void drawSquares(Graphics g, int size, int limit,
            double x, double y) {

        // the carpet is recursively split into 3 x 3 squares
        final int carpetDimension = 3;

        // make new section size
        size = size / carpetDimension;

        // base case
        if(size <= limit) {
            return;
        }

        // draw middle rect
        g.fillRect((int) x + size, (int) y + size, size, size);

        // recursive step
        for(int i = 0; i < carpetDimension; ++i) {
            for(int j = 0; j < carpetDimension; ++j) {
                // don't include middle, but draw/recurse for everything else
                if(!(i == 1 && j == 1)) {
                    drawSquares(g, size, limit, x + size * i, y + size * j);
                }
            }
        }
    }


    /**
     * Problem 6: Determine if water at a given point
     * on a map can flow off the map.
     * <br>pre: map != null, map.length > 0,
     * map is a rectangular matrix, 0 <= row < map.length,
     * 0 <= col < map[0].length
     * <br>post: return true if a drop of water starting at the location
     * specified by row, column can reach the edge of the map,
     * false otherwise.
     * @param map The elevations of a section of a map.
     * @param row The starting row of a drop of water.
     * @param col The starting column of a drop of water.
     * @return return true if a drop of water starting at the location
     * specified by row, column can reach the edge of the map, false otherwise.
     */
    public static boolean canFlowOffMap(int[][] map, int row, int col) {
        if( map == null || map.length == 0 || !isRectangular(map)
                || !inbounds(row, col, map)) {
            throw new IllegalArgumentException("Failed precondition:    "
                    + "canFlowOffMap");
        }

        // base case: if it hits the edge
        if( row == 0 || col == 0 || row == map.length - 1 || col == map[0].length - 1) {
            return true;
        }

        // recursive step
        boolean above = false, below = false, left = false, right = false;
        // test going above
        if(map[row][col] > map[row - 1][col]) {
            above = canFlowOffMap(map, row - 1, col);
        }
        // test going below
        if(map[row][col] > map[row + 1][col]) {
            below = canFlowOffMap(map, row + 1, col);
        }
        // test going left
        if(map[row][col] > map[row][col - 1]) {
            left = canFlowOffMap(map, row, col - 1);
        }
        // test going right
        if(map[row][col] > map[row][col + 1]) {
            right = canFlowOffMap(map, row, col + 1);
        }
        // if one of these flow off, then we can flow off
        return above || below || left || right;
    }

    /* helper method for canFlowOfMap - CS314 students you should not have to
     * call this method,
     * pre: mat != null,
     */
    private static boolean inbounds(int r, int c, int[][] mat) {
        if (mat == null) {
            throw new IllegalArgumentException("Failed precondition: "
                    + "inbounds. The 2d array mat may not be null.");
        }
        return r >= 0 && r < mat.length && mat[r] != null
                && c >= 0 && c < mat[r].length;
    }

    /*
     * helper method for canFlowOfMap - CS314 students you should not have to
     * call this method,
     * pre: mat != null, mat.length > 0
     * post: return true if mat is rectangular
     */
    private static boolean isRectangular(int[][] mat) {
        if (mat == null || mat.length == 0) {
            throw new IllegalArgumentException("Failed precondition: "
                    + "inbounds. The 2d array mat may not be null "
                    + "and must have at least 1 row.");
        }
        boolean correct = true;
        final int numCols = mat[0].length;
        int row = 0;
        while( correct && row < mat.length) {
            correct = (mat[row] != null) && (mat[row].length == numCols);
            row++;
        }
        return correct;
    }


    /**
     * Problem 7: Find the minimum difference possible between teams
     * based on ability scores. The number of teams may be greater than 2.
     * The goal is to minimize the difference between the team with the
     * maximum total ability and the team with the minimum total ability.
     * <br> pre: numTeams >= 2, abilities != null, abilities.length >= numTeams
     * <br> post: return the minimum possible difference between the team
     * with the maximum total ability and the team with the minimum total
     * ability.
     * @param numTeams the number of teams to form.
     * Every team must have at least one member
     * @param abilities the ability scores of the people to distribute
     * @return return the minimum possible difference between the team
     * with the maximum total ability and the team with the minimum total
     * ability. The return value will be greater than or equal to 0.
     */
    public static int minDifference(int numTeams, int[] abilities) {
        // check preconditions
        if (numTeams < 2 || abilities == null || abilities.length < numTeams) {
            throw new IllegalArgumentException("Failed precondition: numTeams >= 2, abilities != null, abilities.length >= numTeams");
        }

        // instantiate some data to be used
        int[] teamSums = new int[numTeams];
        int[] teamMembers = new int[numTeams];
        int startingIndex = 0;

        // call helper for recursion
        return minDifferenceRecurse(teamSums, teamMembers, abilities, startingIndex);
    }

    public static int minDifferenceRecurse(int[] teamSums, int[] teamMembers, int[] abilities, int index) {

        // base case; stop when index reaches the end
        if(index == abilities.length) {
            // check to see if there is at least 1 member per team, and if so then discard
            for(int i = 0; i < teamMembers.length; ++i) {
                if(teamMembers[i] == 0) {
                    return Integer.MAX_VALUE / 2;
                }
            }
            // if not, then return the difference
            return findDifference(teamSums);
        }

        // hold the differences in order to find smallest
        int[] diff = new int[teamSums.length];

        // find all the differences
        for (int i = 0; i < teamSums.length; ++i) {
            // create deepcopy of both arrays
            int[] sumsCopy = copyArray(teamSums);
            int[] memberCopy = copyArray(teamMembers);
            // add persons ability to a team (numTeams times)
            sumsCopy[i] = sumsCopy[i] + abilities[index];
            // indicate the person is on that team
            memberCopy[i] = memberCopy[i] + 1;
            // add recursive result to
            diff[i] = minDifferenceRecurse(sumsCopy, memberCopy, abilities, index + 1);
        }

        // find the smallest difference and return
        int smallest = Integer.MAX_VALUE / 2;
        for(int i = 0; i < diff.length; ++i) {
            if(smallest > diff[i]) {
                smallest = diff[i];
            }
        }
        return smallest;
    }

    // helper to copy arrays
    public static int[] copyArray(int[] arr) {
        int[] copy = new int[arr.length];
        for(int i = 0; i < arr.length; ++i) {
            copy[i] = arr[i];
        }
        return copy;
    }

    // helper to find difference
    public static int findDifference(int[] teamComp) {
        // find largest and smallest val
        int largest = Integer.MIN_VALUE / 2;
        int smallest = Integer.MAX_VALUE / 2;
        for(int i = 0; i < teamComp.length; ++i) {
            // replace largest if larger
            if(teamComp[i] > largest) {
                largest = teamComp[i];
            }
            // replace smallest if smaller
            if(teamComp[i] < smallest) {
                smallest = teamComp[i];
            }
        }
        // return the difference
        return largest - smallest;
    }



    /**
     * Problem 8: Maze solver.
     * <br>pre: board != null
     * <br>pre: board is a rectangular matrix
     * <br>pre: board only contains characters 'S', 'E', '$', 'G', 'Y', and '*'
     * <br>pre: there is a single 'S' character present
     * <br>post: rawMaze is not altered as a result of this method.
     * Return 2 if it is possible to escape the maze after
     * collecting all the coins.
     * Return 1 if it is possible to escape the maze
     * but without collecting all the coins.
     * Return 0 if it is not possible
     * to escape the maze. More details in the assignment handout.
     * @param rawMaze represents the maze we want to escape.
     * rawMaze is not altered as a result of this method.
     * @return per the post condition
     */
    public static int canEscapeMaze(char[][] rawMaze) {
        // check preconditions (will borrow the isRectangular method from canFlowOffMap
        if (rawMaze == null || !isRectangular(rawMaze) || badBoard(rawMaze)) {
            throw new IllegalArgumentException("Failed precondition: board != null, " +
                    "board is a rectangular matrix, board only contains characters 'S', 'E', '$', 'G', 'Y', and '*', " +
                    "there is a single 'S' character present");
        }

        // find the S to start recursion
        int row = -1, col = -1;
        for(int r = 0; r < rawMaze.length; ++r) {
            for(int c = 0; c <rawMaze[r].length; ++c) {
                if(rawMaze[r][c] == 'S') {
                    // save the coordinates of the S
                    row = r;
                    col = c;
                }
            }
        }

        // call the helper for the recursion
        char[][] maze = copyMat(rawMaze);
        return canEscapeMazeRecurse(maze, row, col);

    }

    // helper method for recursion
    public static int canEscapeMazeRecurse(char[][] maze, int row, int col) {
        // base case
        // if we hit impassable square, then return 0
        if(maze[row][col] == '*') {
            return 0;
        // if we made it to exit, investigate
        } else if(maze[row][col] == 'E') {
            // did we collect all coins
            if(coinsCollected(maze)) {
                // if we did, return 2
                return 2;
            }
            // if not, return 1
            return 1;
        }

        // store the values of going up, down, left, right
        int[] values = new int[4];

        // recursive step
        char[][] mazeCopy = copyMat(maze);
        mazeCopy[row][col] = updateCell(mazeCopy[row][col]);

        // go up
        if(row - 1 >= 0) {
            values[0] = canEscapeMazeRecurse(mazeCopy, row - 1, col);
        }
        // go down
        if(row + 1 < maze.length) {
            values[1] = canEscapeMazeRecurse(mazeCopy, row + 1, col);
        }
        // go left
        if(col - 1 >= 0) {
            values[2] = canEscapeMazeRecurse(mazeCopy, row, col - 1);
        }
        // go right
        if(col + 1 < maze[row].length) {
            values[3] = canEscapeMazeRecurse(mazeCopy, row, col + 1);
        }

        // return the highest option available (2, 1, 0) after recursing through up to the 4 paths
        int best = Integer.MIN_VALUE;
        for(int i = 0; i < values.length; ++i) {
            if(best < values[i]) {
                best = values[i];
            }
        }
        return best;
    }

    // helper method borrowed from canFlowOffMap to check if matrix is rectangular
    private static boolean isRectangular(char[][] mat) {
        if (mat == null || mat.length == 0) {
            throw new IllegalArgumentException("Failed precondition: "
                    + "inbounds. The 2d array mat may not be null "
                    + "and must have at least 1 row.");
        }
        boolean correct = true;
        final int numCols = mat[0].length;
        int row = 0;
        while( correct && row < mat.length) {
            correct = (mat[row] != null) && (mat[row].length == numCols);
            row++;
        }
        return correct;
    }

    // helper method to check precondition that board only contains specified chars and a single S
    // if the board doesn't fit conditions then return true because it is bad
    private static boolean badBoard(char[][] board) {
        // store the characters that are considered okay
        char[] legitChars = {'S', 'E', '$', 'G', 'Y', '*'};
        // hold how many S's are in the board
        int numS = 0;
        for(int r = 0; r < board.length; ++r) {
            for(int c = 0; c < board[r].length; ++c) {
                boolean isLegit = false;
                for(int i = 0; i < legitChars.length; ++i) {
                    if(board[r][c] == legitChars[i]) {
                        // if we never change isLegit, then it's a bad board
                        isLegit = true;
                        // if the square is an S, then add to our count
                        if(i == 0) {
                            ++numS;
                        }
                    }
                }
                // if it's a bad board, then return that it is
                if(!isLegit) {
                    return true;
                }
            }
        }

        // check that it's only 1 S
        if(numS != 1) {
            return true;
        }
        // passes all checks saying that it's bad, meaning it must be a good board
        return false;
    }

    // helper method to copy the matrix
    public static char[][] copyMat(char[][] mat) {
        // create an empty copy
        char[][] copy = new char[mat.length][mat[0].length];
        // iterate and fill in that empty copy
        for(int r = 0; r < mat.length; ++r) {
            for(int c = 0; c < mat[r].length; ++c) {
                copy[r][c] = mat[r][c];
            }
        }
        return copy;
    }

    // helper method to return what we should update the cell we just visited to
    public static char updateCell(char prevSquareVal) {
        // if it was starting square, replace with G
        if(prevSquareVal == 'S') {
            return 'G';
        // if it was G or $, replace with Y
        } else if(prevSquareVal == 'G' || prevSquareVal == '$') {
            return 'Y';
        } else {
            // the only other option is that the cell is a 'Y', so it becomes '*'
            return '*';
        }
    }

    // helper method to check if all coins have been collected
    public static boolean coinsCollected(char[][] board) {
        // iterate to check to see that there are no $s; if there is a $, then not all coins are collected
        for(int r = 0; r < board.length; ++r) {
            for(int c = 0; c < board[r].length; ++c) {
                if(board[r][c] == '$') {
                    return false;
                }
            }
        }
        return true;
    }
}