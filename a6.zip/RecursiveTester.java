

/*  Student information for assignment:
 *
 *  On OUR honor, Nathaniel and Adithya, this programming assignment is OUR own work
 *  and WE have not provided this code to any other student.
 *
 *  Number of slip days used: 0
 *
 *  Student 1 (Student whose Canvas account is being used)
 *  UTEID: aa86362
 *  email address: adithya.arunganesh@utexas.edu
 *  Grader name: Pranav
 *  Section number: 50860
 *
 *  Student 2
 *  UTEID: nl9656
 *  email address: nathaniel.li@utexas.edu
 *
 */


import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.Collections;

/**
 * Tester class for the methods in Recursive.java
 * @author scottm
 *
 */
public class RecursiveTester {

    // run the tests
    public static void main(String[] args) {
        studentTests();
    }

    // pre: r != null
    // post: run student test
    private static void studentTests() {
        // CS314 students put your tests here
        doBinaryTests();
        doReverseTests();
        doNextIsDoubleTests();
        doListMnemonicsTests();

        // don't need to test so this method doesn't contain anything
        //doCarpetTest();

        doFlowOffMapTests();
        doFairTeamsTests();
        doMazeTests();
    }

    private static void doBinaryTests() {

        System.out.println();
        System.out.println("getBinary tests");

        // test 1
        System.out.println("Test 1");
        String actual = Recursive.getBinary(10);
        String expected = "1010";

        if(actual.equals(expected)) {
            System.out.println(" --- Passed --- ");
        }else {
            System.out.println(" --- Failed --- ");
        }

        // test 2
        System.out.println("Test 2");
        actual = Recursive.getBinary(-100);
        expected = "-1100100";

        if(actual.equals(expected)) {
            System.out.println(" --- Passed --- ");
        }else {
            System.out.println(" --- Failed --- ");
        }
    }

    private static void doReverseTests() {

        System.out.println();
        System.out.println("revString tests");

        // test 1
        System.out.println("Test 1");
        String actual = Recursive.revString("racecar");
        String expected = "racecar";

        if(actual.equals(expected)) {
            System.out.println(" --- Passed --- ");
        }else {
            System.out.println(" --- Failed --- ");
        }

        // test 2
        System.out.println("Test 2");
        actual = Recursive.revString("test");
        expected = "tset";

        if(actual.equals(expected)) {
            System.out.println(" --- Passed --- ");
        }else {
            System.out.println(" --- Failed --- ");
        }
    }

    private static void doNextIsDoubleTests() {

        System.out.println();
        System.out.println("nextIsDouble tests");

        // test 1
        System.out.println("Test 1");
        int[] a = {1, 2, 3, 4};
        int actual = Recursive.nextIsDouble(a);
        int expected = 1;

        if(actual == expected) {
            System.out.println(" --- Passed --- ");
        }else {
            System.out.println(" --- Failed --- ");
        }

        // test 2
        System.out.println("Test 2");
        int[] b = {1, -2, 4, -8};
        actual = Recursive.nextIsDouble(b);
        expected = 0;

        if(actual == expected) {
            System.out.println(" --- Passed --- ");
        }else {
            System.out.println(" --- Failed --- ");
        }
    }

    private static void doListMnemonicsTests() {

        System.out.println();
        System.out.println("listMnemonics tests");

        // test 1
        System.out.println("Test 1");
        ArrayList<String> actual = Recursive.listMnemonics("1");
        ArrayList<String> expected = new ArrayList<>();
        expected.add("1");

        if(actual.equals(expected)) {
            System.out.println(" --- Passed --- ");
        }else {
            System.out.println(" --- Failed --- ");
        }

        // test 2
        System.out.println("Test 2");
        actual = Recursive.listMnemonics("2");
        expected.clear();
        expected.add("A");
        expected.add("B");
        expected.add("C");

        if(actual.equals(expected)) {
            System.out.println(" --- Passed --- ");
        }else {
            System.out.println(" --- Failed --- ");
        }
    }

    private static void doFlowOffMapTests() {

        System.out.println();
        System.out.println("canFlowOffMap tests");

        // test 1
        System.out.println("Test 1");
        int[][] map = new int[][]{
                {99, 99, 99, 99, 99},
                {99, 99, 99, 99, 99},
                {99, 99, 99, 99, 99},
                {99, 99, 99, 99, 99},
                {99, 99, 99, 99, 99}
        };
        boolean actual = Recursive.canFlowOffMap(map, 1, 1);
        boolean expected = false;

        if(actual == expected) {
            System.out.println(" --- Passed --- ");
        }else {
            System.out.println(" --- Failed --- ");
        }

        // test 2
        System.out.println("Test 2");
        map[1][2] = 50;
        map[1][3] = 49;
        map[1][4] = 48;
        map[2][3] = 47;
        actual = Recursive.canFlowOffMap(map, 1, 2);
        expected = true;

        if(actual == expected) {
            System.out.println(" --- Passed --- ");
        }else {
            System.out.println(" --- Failed --- ");
        }

    }

    private static void doFairTeamsTests() {

        System.out.println();
        System.out.println("minDifference tests");

        // test 1
        System.out.println("Test 1");
        int[] abilities = {1, 2, 3};
        int actual = Recursive.minDifference(2, abilities);
        int expected = 0;

        if(actual == expected) {
            System.out.println(" --- Passed --- ");
        }else {
            System.out.println(" --- Failed --- ");
        }

        // test 2
        System.out.println("Test 2");
        actual = Recursive.minDifference(3, abilities);
        expected = 2;

        if(actual == expected) {
            System.out.println(" --- Passed --- ");
        }else {
            System.out.println(" --- Failed --- ");
        }
    }

    private static void doMazeTests() {

        System.out.println();
        System.out.println("canEscapeMaze tests");

        // test 1
        System.out.println("Test 1");
        char[][] maze = new char[][]{
                {'S', '$', 'E'},
        };
        int actual = Recursive.canEscapeMaze(maze);
        int expected = 2;

        if (actual == expected) {
            System.out.println(" --- Passed --- ");
        } else {
            System.out.println(" --- Failed --- ");
        }

        // test 2
        System.out.println("Test 2");
        maze = new char[][]{
                {'$', 'Y', 'S', '$', 'E'},
        };
        actual = Recursive.canEscapeMaze(maze);
        expected = 1;

        if (actual == expected) {
            System.out.println(" --- Passed --- ");
        } else {
            System.out.println(" --- Failed --- ");
        }
    }
}
