/*  Student information for assignment:
 *
 *  On OUR honor, Andrew and Nathaniel,
 *  this programming assignment is OUR own work
 *  and WE have not provided this code to any other student.
 *
 *  Number of slip days used: 0
 *
 *  Student 1 (Student whose Canvas account is being used)
 *  UTEID: nl9656
 *  email address: nathaniel.li@utexas.edu
 *  TA name: pranav
 *
 *  Student 2
 *  UTEID: ald3967
 *  email address: ditterline.logan@utexas.edu
 */

import java.util.Collections;
import java.util.Iterator;
import java.util.ArrayList;

/**
 * In this implementation of the ISet interface the elements in the Set are 
 * maintained in ascending order.
 *
 * The data type for E must be a type that implements Comparable.
 *
 * Students are to implement methods that were not implemented in AbstractSet 
 * and override methods that can be done more efficiently. An ArrayList must 
 * be used as the internal storage container. For methods involving two set, 
 * if that method can be done more efficiently if the other set is also a 
 * SortedSet do so.
 */
public class SortedSet<E extends Comparable<? super E>> extends AbstractSet<E> {

    private ArrayList<E> myCon;

    /**
     * create an empty SortedSet
     */
    public SortedSet() {
        myCon = new ArrayList<>();
    }

    /**
     * create a SortedSet out of an unsorted set. <br>
     * @param other != null
     */
    public SortedSet(ISet<E> other) {
        // check precondition
        if(other == null) {
            throw new IllegalArgumentException("Failed precondition: other != null");
        }
        Iterator<E> it = other.iterator();
        // add all the elements into myCon
        while(it.hasNext()) {
            myCon.add(it.next());
        }
        // sort it
        mergeSort(0, myCon.size());
    }

    // helper mergeSort method for the instantiation
    private void mergeSort(int left, int right) {
        // break into 2 halves
        if(left < right && right > left) {
            int middle = (left + right) / 2;
            // recurse through the first half
            mergeSort(left, middle);
            // recurse through the second half
            mergeSort(middle + 1, right);
            // merge the two halves
            merge(left, right);
        }
    }

    // place elements in order from [left, right] in myCon
    private void merge(int left, int right) {
        int middle = (left + right) / 2;
        // create listA and listB as temporary arrays
        Object[] listA = new Object[middle - left];
        Object[] listB = new Object[right - middle];
        // copy elements from myCon into listA and listB (temporary arrays)
        for(int i = 0; i < listA.length; i++) {
            listA[i] = myCon.get(i + left);
        }
        for(int i = 0; i < listB.length; i++) {
            listB[i] = myCon.get(i + middle);
        }
        Object[] mergedList = new Object[right - left];
        // index variables for listA, listB, and mergedList
        int aIndex = 0;
        int bIndex = 0;
        int mergedIndex = 0;
        // merge listA and listB into mergedList
        while(aIndex < listA.length && bIndex < listB.length) {
            // insert element from A if it is less than the element in B
            if(((E)listA[aIndex]).compareTo((E)listB[bIndex]) < 0) {
                mergedList[mergedIndex] = listA[aIndex];
                aIndex++;
            } else {
                mergedList[mergedIndex] = listB[bIndex];
                bIndex++;
            }
            mergedIndex++;
        }
        // if there are leftover elements in the first half, add those in
        while(aIndex < listA.length) {
            mergedList[mergedIndex] = listA[aIndex];
            aIndex++;
            mergedIndex++;
        }
        // if there are leftover elements in the second half, add those in
        while(bIndex < listB.length) {
            mergedList[mergedIndex] = listB[bIndex];
            bIndex++;
            mergedIndex++;
        }
        // copy the elements to myCon
        copyToCon(mergedList, left, right);
    }

    // helper method for merge that copys a smaller array to myCon
    private void copyToCon(Object[] array, int left, int right) {
        for(int i = left; i < right; i++) {
            myCon.set(i, (E) array[i - left]);
        }
    }

    /**
     * Return the smallest element in this SortedSet.
     * <br> pre: size() != 0
     * @return the smallest element in this SortedSet.
     */
    public E min() {
        // check precondition
        if(size() == 0) {
            throw new IllegalArgumentException("Failed precondition: size() != 0");
        }
        // since it's in order, return the first element
        return myCon.get(0);
    }

    /**
     * Return the largest element in this SortedSet.
     * <br> pre: size() != 0
     * @return the largest element in this SortedSet.
     */
    public E max() {
        // check precondition
        if(size() == 0) {
            throw new IllegalArgumentException("Failed precondition: size() != 0");
        }
        // since it's in order, return the last element
        return myCon.get(myCon.size() - 1);
    }

    /**
     * Add an item to this set.
     * <br> item != null
     * @param item the item to be added to this set. item may not equal null.
     * @return true if this set changed as a result of this operation,
     * false otherwise.
     */
    public boolean add(E item) {
        // check precondition
        if(item == null) {
            throw new IllegalArgumentException("Failed precondition: item != null");
        }
        // make sure the set doesn't contain the element
        if(contains(item)) {
            return false;
        }
        // if myCon is empty, we can just add it
        if(myCon.size() == 0) {
            myCon.add(item);
        // if not, then we need to find where to add
        } else {
            // iterate to find where we should add
            int index = 0;
            while(index < myCon.size() && myCon.get(index).compareTo(item) < 0) {
                index++;
            }
            myCon.add(index, item);
            return true;
        }
        return false;
    }

    /**
     * A union operation. Add all items of otherSet that
     * are not already present in this set to this set.
     * @param otherSet != null
     * @return true if this set changed as a result of this operation,
     * false otherwise.
     */
    public boolean addAll(ISet<E> otherSet) {
        // check precondition
        if(otherSet == null) {
            throw new IllegalArgumentException("Failed precondition: otherSet != null");
        }
        // keep track of what needs to be returned
        boolean changed = false;
        Iterator<E> it = otherSet.iterator();
        // if we are adding with sortedSet
        if(otherSet instanceof SortedSet) {
            int i = 0;
            E temp = it.next();
            // iterate through both sets
            while(it.hasNext() && i < size()) {
                // if element from this set is less than the element from other set
                if(myCon.get(i).compareTo(temp) < 0) {
                    // we move to the next element in this set
                    ++i;
                // if element from this set is equal to other set, skip over
                } else if(myCon.get(i).compareTo(temp) == 0) {
                    // move onto next elements in both sets
                    temp = it.next();
                    ++i;
                // if element from this set is greater than element other set
                } else {
                    // add the other element, and increment other set
                    changed = true;
                    myCon.add(temp);
                    temp = it.next();
                }
            }
        // if we aren't adding elements from a sortedSet then just add normally
        } else {
            while(it.hasNext()) {
                add(it.next());
            }
        }
        return changed;
    }

    /**
     * Make this set empty.
     * <br>pre: none
     * <br>post: size() = 0
     */
    public void clear() {
        // clear container
        myCon.clear();
    }

    /**
     * Determine if item is in this set.
     * <br>pre: item != null
     * @param item element whose presence is being tested.
     * Item may not equal null.
     * @return true if this set contains the specified item, false otherwise.
     */
    public boolean contains(E item) {
        // check precondition
        if(item == null) {
            throw new IllegalArgumentException("Failed precondition: item != null");
        }
        // can't contain anything if empty
        if(myCon.size() == 0) {
            return false;
        }
        // if the set holds a different type, can't contain
        if(!item.getClass().equals(myCon.get(0).getClass())) {
            return false;
        }
        // binary search to find if it contains
        return search(item, 0, myCon.size()) != -1;
    }


    /**
     * Determine if all of the elements of otherSet are in this set.
     * <br> pre: otherSet != null
     * @param otherSet != null
     * @return true if this set contains all of the elements in otherSet,
     * false otherwise.
     */
    public boolean containsAll(ISet<E> otherSet) {
        // check precondition
        if(otherSet == null) {
            throw new IllegalArgumentException("Failed precondition: otherSet != null");
        }
        // can't contain all elements of a different set if smaller
        if(myCon.size() < otherSet.size()) {
            return false;
        }
        // both empty, then this will contain other
        if(myCon.size() == 0 && otherSet.size() == 0) {
            return true;
        }

        Iterator<E> it = otherSet.iterator();
        // if the set holds a different type, can't contain
        E temp = it.next();
        if(!temp.getClass().equals(myCon.get(0).getClass())) {
            return false;
        }
        // if the otherSet is a sortedSet
        if(otherSet instanceof SortedSet) {
            int i = 0;
            // iterate
            while(it.hasNext() && i < size()) {
                // if this element is less, then we look at our next element
                if(myCon.get(i).compareTo(temp) < 0) {
                    ++i;
                // if this element is the same, then it contains it, so move on
                } else if(myCon.get(i).compareTo(temp) == 0) {
                    temp = it.next();
                    ++i;
                // if we ever have an element that is greater, then it can't possibly contain an element less
                } else {
                    return false;
                }
            }
        // if the otherSet is unsortedSet
        } else {
            // iterate and check each individual other element
            while(it.hasNext()) {
                if(!contains(it.next())) {
                    return false;
                }
            }
        }
        return true;
    }

    // binary search helper method for contains
    private int search(E item, int left, int right) {
        // find the middle
        int middle = (left + right) / 2;
        // base case for if can't find
        if(left == right || left > right || right < left) {
            return -1;
        }
        // if we do find a match, return
        if(myCon.get(middle).compareTo(item) == 0) {
            return middle;
        // recurse both sides of middle
        } else if(myCon.get(middle).compareTo(item) > 0) {
            return search(item, left, middle);
        } else {
            return search(item, middle + 1, right);
        }
    }


    /**
     * Create a new set that is the difference of this set and otherSet.
     * Return an ISet of elements that are in this Set but not in otherSet.
     * Also called the relative complement.
     * <br>Example: If ISet A contains [X, Y, Z] and ISet B contains [W, Z]
     * then A.difference(B) would return an ISet with elements [X, Y] while
     * B.difference(A) would return an ISet with elements [W].
     * <br>pre: otherSet != null
     * <br>post: returns a set that is the difference of this set and otherSet.
     * Neither this set or otherSet are altered as a result of this operation.
     * <br> pre: otherSet != null
     * @param otherSet != null
     * @return a set that is the difference of this set and otherSet
     */
    public SortedSet difference(ISet<E> otherSet) {
        // check precondition
        if(otherSet == null) {
            throw new IllegalArgumentException("Failed precondition: otherSet != null");
        }
        // instantiate return structure
        SortedSet<E> ret = new SortedSet<E>();
        Iterator<E> it = otherSet.iterator();
        int i = 0;
        E temp = it.next();
        // iterate
        while(it.hasNext() && i < size()) {
            // we add to difference if this element is less and therefore not in other
            if(myCon.get(i).compareTo(temp) < 0) {
                ret.add(myCon.get(i));
                ++i;
            // move on to next elements if same (don't add because it is in other)
            } else if(myCon.get(i).compareTo(temp) == 0) {
                temp = it.next();
                ++i;
            // move on to next for other element if this is larger
            } else {
                temp = it.next();
            }
        }
        return ret;
    }


    /**
     * Determine if this set is equal to other.
     * Two sets are equal if they have exactly the same elements.
     * The order of the elements does not matter.
     * <br>pre: none
     * @param other the object to compare to this set
     * @return true if other is a Set and has the same elements as this set
     */
    public boolean equals(Object other) {
        // check precondition
        if(!(other instanceof AbstractSet)) {
            return false;
        }
        // if they point to the same thing, then it's equal
        if(other == this) {
            return true;
        }
        // if sorted set
        if(other instanceof SortedSet) {
            Iterator<E> itThis = iterator();
            Iterator<E> itOther = ((SortedSet)other).iterator();
            // compare mirroring elements
            while(itThis.hasNext() && itOther.hasNext()) {
                if(!itThis.next().equals(itOther.next())) {
                    return false;
                }
            }
        // if not sorted set, then look at parent method
        } else {
            return super.equals(other);
        }
        return true;
    }


    /**
     * create a new set that is the intersection of this set and otherSet.
     * <br>pre: otherSet != null<br>
     * <br>post: returns a set that is the intersection of this set
     * and otherSet.
     * Neither this set or otherSet are altered as a result of this operation.
     * <br> pre: otherSet != null
     * @param otherSet != null
     * @return a set that is the intersection of this set and otherSet
     */
    public SortedSet intersection(ISet<E> otherSet) {
        // check precondition
        if(otherSet == null) {
            throw new IllegalArgumentException("Failed precondition: otherSet != null");
        }
        // instantiate return structure
        SortedSet<E> ret = new SortedSet<E>();
        Iterator<E> it = otherSet.iterator();
        int i = 0;
        E temp = it.next();
        // iterate
        while(it.hasNext() && i < size()) {
            // don't add if element is in this, but not in other
            if(myCon.get(i).compareTo(temp) < 0) {
                ++i;
            // add if element is in this and other
            } else if(myCon.get(i).compareTo(temp) == 0) {
                ret.add(myCon.get(i));
                temp = it.next();
                ++i;
            // don't add if element is in other, but not in this
            } else {
                temp = it.next();
            }
        }
        return ret;
    }


    /**
     * Return an Iterator object for the elements of this set.
     * pre: none
     * @return an Iterator object for the elements of this set
     */
    public Iterator<E> iterator() {
        // return pre-made iterator
        return myCon.iterator();
    }


    /**
     * Create a new set that is the union of this set and otherSet.
     * <br>pre: otherSet != null
     * <br>post: returns a set that is the union of this set and otherSet.
     * Neither this set or otherSet are altered as a result of this operation.
     * <br> pre: otherSet != null
     * @param otherSet != null
     * @return a set that is the union of this set and otherSet
     */
    public SortedSet union(ISet<E> otherSet) {
        // check precondition
        if(otherSet == null) {
            throw new IllegalArgumentException("Failed precondition: otherSet != null");
        }
        // instantiate return structure
        SortedSet<E> ret = new SortedSet<E>();
        Iterator<E> it = otherSet.iterator();
        int i = 0;
        E temp = it.next();
        // iterate
        while(it.hasNext() && i < size()) {
            // add the element and increment
            if(myCon.get(i).compareTo(temp) < 0) {
                ret.add(myCon.get(i));
                ++i;
            // add the element and increment
            } else if(myCon.get(i).compareTo(temp) == 0) {
                ret.add(myCon.get(i));
                temp = it.next();
                ++i;
            // add the element and increment
            } else {
                ret.add(temp);
                temp = it.next();
            }
        }
        return ret;
    }
}
