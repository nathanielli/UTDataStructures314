/*  Student information for assignment:
 *
 *  On my honor, <NAME>, this programming assignment is my own work
 *  and I have not provided this code to any other student.
 *
 *  Name: Nathaniel Li
 *  email address: nathaniel.li@utexas.edu
 *  UTEID: nl9656
 *  Section 5 digit ID: 50860
 *  Grader name:
 *  Number of slip days used on this assignment:
 */

// add imports as necessary

import java.util.*;

/**
 * Manages the details of EvilHangman. This class keeps
 * tracks of the possible words from a dictionary during
 * rounds of hangman, based on guesses so far.
 *
 */
public class HangmanManager {

    // instance vars
    boolean debugOn;
    Set<String> words, wordsLeft;
    Set<Character> guesses;
    int wordLen, numGuesses, wrongGuess;
    HangmanDifficulty diff;
    String secretWord, pattern;


    /**
     * Create a new HangmanManager from the provided set of words and phrases.
     * pre: words != null, words.size() > 0
     * @param words A set with the words for this instance of Hangman.
     * @param debugOn true if we should print out debugging to System.out.
     */
    public HangmanManager(Set<String> words, boolean debugOn) {
        this.words = words;
        this.debugOn = debugOn;
    }


    /**
     * Create a new HangmanManager from the provided set of words and phrases.
     * Debugging is off.
     * pre: words != null, words.size() > 0
     * @param words A set with the words for this instance of Hangman.
     */
    public HangmanManager(Set<String> words) {
        this.words = words;
        debugOn = false;
    }


    /**
     * Get the number of words in this HangmanManager of the given length.
     * pre: none
     * @param length The given length to check.
     * @return the number of words in the original Dictionary
     * with the given length
     */
    public int numWords(int length) {
        int counter = 0;
        for(String word : words) {
            if(word.length() == length) {
                ++counter;
            }
        }
        return counter;
    }


    /**
     * Get for a new round of Hangman. Think of a round as a
     * complete game of Hangman.
     * @param wordLen the length of the word to pick this time.
     * numWords(wordLen) > 0
     * @param numGuesses the number of wrong guesses before the
     * player loses the round. numGuesses >= 1
     * @param diff The difficulty for this round.
     */
    public void prepForRound(int wordLen, int numGuesses, HangmanDifficulty diff) {
        // check pre
        if (numWords(wordLen) <= 0 || numGuesses < 1) {
            throw new IllegalArgumentException("Violation of precondition: numWords(wordLen) > 0 or numGuesses >= 1");
        }
        // reset everything
        this.wordLen = wordLen;
        this.numGuesses = numGuesses;
        guesses = new TreeSet<>();
        this.diff = diff;
        pattern = "";
        for(int i=0; i<wordLen; ++i) {
            pattern+="-";
        }
        wrongGuess = 0;
        wordsLeft = new TreeSet<>();
        for(String word : words){
            if(word.length() == wordLen){
                wordsLeft.add(word);
            }
        }

    }


    /**
     * The number of words still possible (live) based on the guesses so far.
     *  Guesses will eliminate possible words.
     * @return the number of words that are still possibilities based on the
     * original dictionary and the guesses so far.
     */
    public int numWordsCurrent() {
        return wordsLeft.size();
    }


    /**
     * Get the number of wrong guesses the user has left in
     * this round (game) of Hangman.
     * @return the number of wrong guesses the user has left
     * in this round (game) of Hangman.
     */
    public int getGuessesLeft() {
        return numGuesses - wrongGuess;
    }


    /**
     * Return a String that contains the letters the user has guessed
     * so far during this round.
     * The characters in the String are in alphabetical order.
     * The String is in the form [let1, let2, let3, ... letN].
     * For example [a, c, e, s, t, z]
     * @return a String that contains the letters the user
     * has guessed so far during this round.
     */
    public String getGuessesMade() {
        if(guesses.size() == 0){
            return "[]";
        }
        String temp = "[";
        for(Character guess : guesses) {
            temp = temp + guess + ", ";
        }
        String ret = temp.substring(0,temp.length()-2) + "]";
        return ret;
    }


    /**
     * Check the status of a character.
     * @param guess The characater to check.
     * @return true if guess has been used or guessed this round of Hangman,
     * false otherwise.
     */
    public boolean alreadyGuessed(char guess) {
        return guesses.contains(guess);
    }


    /**
     * Get the current pattern. The pattern contains '-''s for
     * unrevealed (or guessed)
     * characters and the actual character for "correctly guessed" characters.
     * @return the current pattern.
     */
    public String getPattern() {
        return pattern;
    }


    // helper class that updates the pattern
    public String makePattern(String word, char guess) {
        String newPattern = "";
        // loop through
        for(int i=0; i<word.length(); ++i) {
            // add characters onto pattern 1 by 1
            if(word.charAt(i) == guess) {
                newPattern += guess;
            }else{
                newPattern += pattern.charAt(i);
            }
        }
        return newPattern;
    }


    /**
     * Update the game status (pattern, wrong guesses, word list),
     * based on the give guess.
     * @param guess pre: !alreadyGuessed(ch), the current guessed character
     * @return return a tree map with the resulting patterns and the number of
     * words in each of the new patterns.
     * The return value is for testing and debugging purposes.
     */
    public TreeMap<String, Integer> makeGuess(char guess) {
        // check pre
        if (alreadyGuessed(guess)) {
            throw new IllegalStateException("Can't guess something you already guessed");
        }
        guesses.add(guess);
        // create the local storing structures
        TreeMap<String, Integer> wordList = new TreeMap<String, Integer>();

        // sort wordsLeft into wordList
        for(String word : wordsLeft) {
            String newPattern = makePattern(word, guess);
            if(wordList.containsKey(newPattern)) {
                wordList.put(newPattern, wordList.get(newPattern) + 1);
            } else {
                wordList.put(newPattern, 1);
            }
        }

        // check difficulty
        Collection<Integer> values = wordList.values();
        // get the highest and second highest values
        int max = 0, secondMax = 0;
        String maxPat = "", secondMaxPat = "";
        for(Map.Entry<String, Integer> ntry: wordList.entrySet()) {
            // greater than max then gotta replace 2 things
            if(ntry.getValue() > max){
                secondMax = max;
                secondMaxPat = maxPat;
                max = ntry.getValue();
                maxPat = ntry.getKey();
            // greater than 2nd max then gotta replace only 1 thing
            } else if(ntry.getValue() > secondMax) {
                secondMax = ntry.getValue();
                secondMaxPat = ntry.getKey();
            }
        }

        // update instance vars
        // make some temp vars
        Set<String> temp = new TreeSet<>();
        String tempPat;

        // if there is no second, then choose first
        if(secondMaxPat.equals("")){
            secondMaxPat = maxPat;
        }
        // if secondhardest
        if((diff == HangmanDifficulty.EASY && guesses.size() % 2 == 0) ||
                (diff == HangmanDifficulty.MEDIUM && guesses.size() % 4 == 0)) {
            tempPat = secondMaxPat;
        } else {
            tempPat = maxPat;
        }

        // new wordsLeft
        for(String word : wordsLeft) {
            if(tempPat.equals(makePattern(word, guess))) {
                temp.add(word);
            }
        }

        // if the guess was wrong
        if(tempPat.equals(pattern)) {
            ++wrongGuess;
        }

        // untemporarize
        pattern = tempPat;
        wordsLeft = temp;

        return wordList;
    }


    /**
     * Return the secret word this HangmanManager finally ended up
     * picking for this round.
     * If there are multiple possible words left one is selected at random.
     * <br> pre: numWordsCurrent() > 0
     * @return return the secret word the manager picked.
     */
    public String getSecretWord() {
        return secretWord;
    }
}
