/* CS 314 STUDENTS: FILL IN THIS HEADER.
 *
 * Student information for assignment:
 *
 *  On my honor, Nathaniel Li, this programming assignment is my own work
 *  and I have not provided this code to any other student.
 *
 *  UTEID: nl9656
 *  email address: nathaniel.li@utexas.edu
 *  TA name:
 *  Number of slip days I am using: 1
 */

public class LetterInventory {

    // variable to store the 26 magic number
    private final int numLetters = 26;
    // store the counts of each letter (letter inventory) in the word
    private int[] letCount = new int[numLetters];
    // size of how many characters in the inventory
    private int size = 0;
    // an array of the alphabet in order
    private char[] letters = {'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n',
            'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z'};

    // pre: string is not null
    public LetterInventory(String s) {
        // check precondition
        if(s == null) {
            throw new IllegalArgumentException("Failed precondition: string should not be null");
        }
        // recurse through the string and letters to add to inventory
        for(int i = 0; i < s.length(); ++i) {
            char ch = s.toLowerCase().charAt(i);
            // check to see if the character is within a and z
            if('a' <= ch && ch <= 'z') {
                letCount[ch - 97] = letCount[ch - 97] + 1;
                ++size;
            }
        }
    }

    // Accepts a char and returns the frequency of that letter in this LetterInventory.
    // The precondition requires that the char be an English letter. It may be an upper or lower case letter.
    // The answer returned must be the same given the upper or lower case version of a letter. This method shall be O(1).
    public int get(char ch) {
        return letCount[Character.toLowerCase(ch) - 97];
    }

    // Returns the total number of letters in this LetterInventory. This method shall be O(1).
    public int size() {
        return size;
    }

    // Returns true if the size of this LetterInventory is 0, false otherwise.
    // This method shall be O(1) with respect to the size of the alphabet.
    public boolean isEmpty() {
        return (size == 0);
    }

    // Returns a String representation of this LetterInventory. All letters in the inventory are listed in alphabetical order.
    public String toString() {
        String ret = "";
        // recurse through letCount and add
        for(int i = 0; i < letCount.length; ++i) {
            for(int j = 0; j < letCount[i]; ++j) {
                ret = ret + letters[i];
            }
        }
        return ret;
    }

    // Returns a new LetterInventory created by adding the frequencies from the calling
    // LetterInventory object to the frequencies of the letters in the explicit parameter.
    // The precondition requires that the LetterInventory sent as an explicit parameter not be null.
    // The postcondition requires that neither the calling object or the explicit parameter are altered as a result of this method call.
    public LetterInventory add(LetterInventory li) {
        // check precondition
        if(li == null) {
            throw new IllegalArgumentException("Failed precondition: the LetterInventory sent as an explicit parameter not be null");
        }
        LetterInventory ret = new LetterInventory(li.toString() + toString());
        return ret;
    }

    // returns a new LetterInventory object created by subtracting the
    // letter frequencies of the explicit parameter from the calling object's (this) letter frequencies
    public LetterInventory subtract(LetterInventory li) {
        // check precondition
        if(li == null) {
            throw new IllegalArgumentException("Failed precondition: the LetterInventory sent as an explicit parameter not be null");
        }

        // find the frequencies of the letters in the new
        int[] oldLetCount = li.getLetCount();
        int[] newLetCount = new int[numLetters];
        for(int i = 0; i < newLetCount.length; ++i) {
            newLetCount[i] = letCount[i] - oldLetCount[i];
            // if less than 0, we return null
            if(newLetCount[i] < 0) {
                return null;
            }
        }

        // create a string with the new frequencies
        LetterInventory ret = new LetterInventory(makeString(newLetCount));
        return ret;
    }

    // method that gets the count of letters array letCount within the letterinventory
    public int[] getLetCount() {
        return letCount;
    }

    // helper method that creates the string representation of an array of frequencies
    private String makeString(int[] letFreq) {
        String ret = "";
        // recurse through letFreq and add
        for(int i = 0; i < letFreq.length; ++i) {
            for(int j = 0; j < letFreq[i]; ++j) {
                ret = ret + letters[i];
            }
        }
        return ret;
    }

    // Two LetterInventorys are equal if the frequency for each letter in the alphabet is the same.
    // The parameter shall be of be Object.
    public boolean equals(Object obj) {
        LetterInventory temp = (LetterInventory) obj;
        // iterate through letCount to compare
        for(int i = 0; i <letCount.length; ++i) {
            if(letCount[i] != temp.get(letters[i])) {
                return false;
            }
        }
        return true;
    }
}
