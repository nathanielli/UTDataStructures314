/* CS 314 STUDENTS: FILL IN THIS HEADER.
 *
 * Student information for assignment:
 *
 *  On my honor, Nathaniel Li, this programming assignment is my own work
 *  and I have not provided this code to any other student.
 *
 *  UTEID: nl9656
 *  email address: nathaniel.li@utexas.edu
 *  TA name:
 *  Number of slip days I am using: 1
 */


import java.util.*;


public class AnagramSolver {

    TreeMap<String, LetterInventory> words = new TreeMap<String, LetterInventory>();
    ArrayList<String> lessWords = new ArrayList<>();
    List<List<String>> ans = new ArrayList<List<String>>();

    /*
     * pre: list != null
     * @param list Contains the words to form anagrams from.
     */
    public AnagramSolver(Set<String> dictionary) {
        // CS314 Students, add your code here
        for(String word : dictionary) {
            if(!words.containsKey(word)) {
                LetterInventory li = new LetterInventory(word);
                words.put(word, li);
            }
        }
    }

    /*
     * pre: maxWords >= 0, s != null, s contains at least one 
     * English letter.
     * Return a list of anagrams that can be formed from s with
     * no more than maxWords, unless maxWords is 0 in which case
     * there is no limit on the number of words in the anagram
     */
    public List<List<String>> getAnagrams(String s, int maxWords) {
        // CS314 Students, add your code here.
        // check precondition
        if(s == null || maxWords < 0 || !containsEng(s)) {
            throw new IllegalArgumentException("Failed precondition: string should not be null, maxwords >= 0, " +
                    "contains at least one English Letter");
        }
        // if maxWords is 0, then we have unlimited capacity
        if(maxWords == 0) {
            maxWords = Integer.MAX_VALUE;
        }

        // first clear the answer we are going to modify return as well as lessWords
        ans.clear();
        lessWords.clear();
        int startingIndex = 0;
        LetterInventory li = new LetterInventory(s);

        // add only the words that are possible to lesswords
        for(String word : words.keySet()) {
            if(li.subtract(words.get(word)) != null) {
                lessWords.add(word);
            }
        }

        // call the helper method to recurse
        ArrayList<String> wordsSoFar = new ArrayList<String>();
        anagramRecurse(li, maxWords, wordsSoFar, startingIndex);

        // sort before return
        AnagramComparator ac = new AnagramComparator();
        Collections.sort(ans, ac);

        // return our answer
        return ans;

    }

    // helper method that actually does the recursion
    public void anagramRecurse(LetterInventory lettersLeft, int wordsLeft, ArrayList<String> wordsSoFar, int startingIndex) {
        // base case
        // we got what we wanted with no more letters left or available words left
        if(lettersLeft.isEmpty()) {
            ans.add((List<String>) wordsSoFar.clone());
            return;
        } else if(wordsLeft == 0) {
            return;
        }

        // recursive step
        for(int i = startingIndex; i < lessWords.size(); ++i) {
            LetterInventory newLettersLeft = lettersLeft.subtract(words.get(lessWords.get(i)));
            if(newLettersLeft != null) {
                wordsSoFar.add(lessWords.get(i));
                anagramRecurse(newLettersLeft, wordsLeft - 1, wordsSoFar, i);
                wordsSoFar.remove(wordsSoFar.size() - 1);
            }
        }
    }

    // helper method that checks if a string contains at least 1 english letter
    private boolean containsEng(String str) {
        // first make string all same case
        String s = str.toLowerCase();
        // iterate through the string
        for(int i = 0; i < s.length(); ++i) {
            // check if the character is an english letter
            char ch = s.charAt(i);
            if('a' <= ch && ch <= 'z') {
                return true;
            }
        }
        // the String doesn't have an english letter character
        return false;
    }

    private class AnagramComparator implements Comparator<List<String>> {
        public int compare(List<String> listA, List<String> listB) {
            int ret = Integer.compare(listA.size(), listB.size());
            int i = 0;
            while(ret == 0 && i < listA.size()) {
                ret = listA.get(i).compareTo(listB.get(i++));
            }
            return ret;
        }
    }
}