//  CodeCamp.java - CS314 Assignment 1

/*  Student information for assignment:
 *
 *  replace <NAME> with your name.
 *
 *  On my honor, Nathaniel, this programming assignment is my own work
 *  and I have not provided this code to any other student.
 *
 *  Name: Nathaniel Li
 *  email address: nathaniel.li@utexas.edu
 *  UTEID: nl9656
 *  Section 5 digit ID: 50860
 *  Grader name:
 *  Number of slip days used on this assignment: 0
 */

import java.util.Random;

public class CodeCamp {

    /**
     * Determine the Hamming distance between two arrays of ints. 
     * Neither the parameter <tt>aData</tt> or
     * <tt>bData</tt> are altered as a result of this method.<br>
     * @param aData != null, aData.length == aData.length
     * @param bData != null
     * @return the Hamming Distance between the two arrays of ints.
     */
    public static int hammingDistance(int[] aData, int[] bData) {
        // check preconditions
        if (aData == null || bData == null || aData.length != bData.length) {
            throw new IllegalArgumentException("Violation of precondition: " +
                    "hammingDistance. neither parameter may equal null, arrays" +
                    " must be equal length.");
        }

        // initialize counter
        int hammingDistCount = 0;
        // loop through and see if the respective elements are different
        for(int i=0; i<aData.length; ++i){
            if(aData[i] != bData[i]){
                // if they are different, then increment counter
                ++hammingDistCount;
            }
        }
        return hammingDistCount;
    }


    /**
     * Determine if one array of ints is a permutation of another.
     * Neither the parameter <tt>aData</tt> or 
     * the parameter <tt>bData</tt> are altered as a result of this method.<br>
     * @param aData != null
     * @param bData != null
     * @return <tt>true</tt> if aData is a permutation of bData, 
     * <tt>false</tt> otherwise
     *
     */
    public static boolean isPermutation(int[] aData, int[] bData) {
        // check preconditions
        if (aData == null || bData == null) {
            throw new IllegalArgumentException("Violation of precondition: " +
                    "isPermutation. neither parameter may equal null.");
        }

        // if the lengths don't match then return False
        if(aData.length != bData.length){
            return false;
        }

        // just do a simple insertion sort thingy on both arrays (wah collections.sort)
        int[] aArr = sort(aData);

        //again for bData
        int[] bArr = sort(bData);

        // if hamming distance between the two sorted is >0, then it's not a permutation
        if(hammingDistance(aArr, bArr) > 0){
            return false;
        }
        return true;
    }

    // sort for isPermutation method
    private static int[] sort(int[] a){
        // make a copy of the array
        int[] arr = new int[a.length];
        for(int i=0; i<a.length; ++i){
            arr[i] = a[i];
        }

        // sort
        for(int i=1; i<arr.length; ++i){
            int value = arr[i];
            int j = i - 1;
            while(j >= 0 && arr[j] > value){
                arr[j+1] = arr[j];
                --j;
            }
            arr[j+1] = value;
        }
        return arr;
    }


    /**
     * Determine the index of the String that 
     * has the largest number of vowels. 
     * Vowels are defined as <tt>'A', 'a', 'E', 'e', 'I', 'i', 'O', 'o', 
     * 'U', and 'u'</tt>.
     * The parameter <tt>arrayOfStrings</tt> is not altered as a result of this method.
     * <p>pre: <tt>arrayOfStrings != null</tt>, <tt>arrayOfStrings.length > 0</tt>, 
     * there is an least 1 non null element in arrayOfStrings.
     * <p>post: return the index of the non-null element in arrayOfStrings that has the 
     * largest number of characters that are vowels.
     * If there is a tie return the index closest to zero. 
     * The empty String, "", has zero vowels.
     * It is possible for the maximum number of vowels to be 0.<br>
     * @param arrayOfStrings the array to check
     * @return the index of the non-null element in arrayOfStrings that has 
     * the largest number of vowels.
     */
    public static int mostVowels(String[] arrayOfStrings) {
        // check preconditions
        if (arrayOfStrings == null || arrayOfStrings.length == 0 || !atLeastOneNonNull(arrayOfStrings)) {
            throw new IllegalArgumentException("Violation of precondition: " +
                    "mostVowels. parameter may not equal null and must contain " +
                    "at least one none null value.");
        }

        // index with the most vowels so far... will ultimately return this
        int indexWithMostVowel = -1;
        int mostVowels = -1;

        // array of the vowels
        char[] vowels = {'A', 'a', 'E', 'e', 'I', 'i', 'O', 'o', 'U', 'u'};

        // loop through arrayOfStrings
        for(int i=0; i<arrayOfStrings.length; ++i){
            // make a count of how many vowels each element has
            int vowelCount = 0;

            // first check if it's null
            if(arrayOfStrings[i] != null){
                // make a array of characters of each element
                char[] current = new char[arrayOfStrings[i].length()];
                for (int j = 0; j < arrayOfStrings[i].length(); ++j) {
                    current[j] = arrayOfStrings[i].charAt(j);
                }
                // compare to the array of vowels
                for (int j = 0; j < current.length; ++j) {
                    for (int k = 0; k < vowels.length; ++k) {
                        // if we see that it is a vowel, then increment vowel count and break
                        if (current[j] == vowels[k]) {
                            ++vowelCount;
                            break;
                        }
                    }
                }
                // if we have a new greatest count then replace
                if(vowelCount > mostVowels) {
                    indexWithMostVowel = i;
                    mostVowels = vowelCount;
                }
            }
        }

        return indexWithMostVowel;
    }



    /**
     * Perform an experiment simulating the birthday problem.
     * Pick random birthdays for the given number of people. 
     * Return the number of pairs of people that share the
     * same birthday.<br>
     * @param numPeople The number of people in the experiment.
     * This value must be > 0
     * @param numDaysInYear The number of days in the year for this experiement.
     * This value must be > 0
     * @return The number of pairs of people that share a birthday 
     * after running the simulation.
     */
    public static int sharedBirthdays(int numPeople, int numDaysInYear) {
        // check preconditions
        if (numPeople <= 0 || numDaysInYear <= 0) {
            throw new IllegalArgumentException("Violation of precondition: " +
                    "sharedBirthdays. both parameters must be greater than 0. " +
                    "numPeople: " + numPeople +
                    ", numDaysInYear: " + numDaysInYear);
        }

        // I will number the days as such: January 1 = '0', January 2 = '1', ...
        // December 31 = 364 (If numDaysInYear is 365)

        // an array to keep track of all of the birthdays
        int[] birthdays = new int[numPeople];
        // a counter for number of pairs (order specific, so we must divide by 2! to obtain
        // actual answer because order doesn't actually matter
        int numPairs = 0;
        // generate the random birthdays
        for(int i=0; i<numPeople; ++i){
            birthdays[i] = (int)(Math.random()*numDaysInYear);
        }
        // iterate through with each birthday trying to find a pair
        for(int i=0; i<numPeople; ++i) {
            int currentBday = birthdays[i];
            for (int j = 0; j<numPeople; ++j) {
                // if it's not yourself, and it's someone elses matching bday then increment!
                if (j != i && currentBday == birthdays[j]) {
                    ++numPairs;
                }
            }
        }

        return numPairs/2;
    }


    /**
     * Determine if the chess board represented by board is a safe set up.
     * <p>pre: board != null, board.length > 0, board is a square matrix.
     * (In other words all rows in board have board.length columns.),
     * all elements of board == 'q' or '.'. 'q's represent queens, '.'s
     * represent open spaces.<br>
     * <p>post: return true if the configuration of board is safe,
     * that is no queen can attack any other queen on the board.
     * false otherwise.
     * the parameter <tt>board</tt> is not altered as a result of 
     * this method.<br>
     * @param board the chessboard
     * @return true if the configuration of board is safe,
     * that is no queen can attack any other queen on the board.
     * false otherwise.
     */
    public static boolean queensAreSafe(char[][] board) {
        char[] validChars = {'q', '.'};
        // check preconditions
        if (board == null || board.length == 0 || !isSquare(board)
                || !onlyContains(board, validChars)) {
            throw new IllegalArgumentException("Violation of precondition: " +
                    "queensAreSafe. The board may not be null, must be square, " +
                    "and may only contain 'q's and '.'s");
        }

        // first find how many queens
        int numQueens = 0;
        for(int r=0; r<board.length; ++r){
            for(int c=0; c<board[r].length; ++c){
                if(board[r][c] == 'q'){
                    ++numQueens;
                }
            }
        }

        // find coords of all queens
        // r coords are stored here
        int[] queensR = new int[numQueens];
        // c coords are stored here
        int[] queensC = new int[numQueens];
        // index of which queen
        int index = 0;
        // loop through board
        for(int r=0; r<board.length; ++r){
            for(int c=0; c<board[r].length; ++c){
                // record the coordinates
                if(board[r][c] == 'q'){
                    queensR[index] = r;
                    queensC[index] = c;
                    ++index;
                }
            }
        }

        // check horizontals for every queen
        boolean horizontalSafe = checkHorizontals(board, numQueens, queensR, queensC);

        // check verticals for every queen
        boolean verticalSafe = checkVerticals(board, numQueens, queensR, queensC);

        // check diagonals (bottom left to top right) for every queen
        boolean diagonal1Safe = checkDiagonals1(board, numQueens, queensR, queensC);


        // check diagonals (bottom right to top left) for every queen
        boolean diagonal2Safe = checkDiagonals2(board, numQueens, queensR, queensC);

        // all must be safe in order for queens to be truly safe
        return horizontalSafe && verticalSafe && diagonal1Safe && diagonal2Safe;
    }

    // helper method for method queensAreSafe that checks if the queens are safe horizontally
    private static boolean checkHorizontals(char[][] board, int numQueens, int[] queensR, int[] queensC){
        // check if any of the rows are the same (THAT WOULD BE UNSAFE)
        for(int i=0; i<numQueens; ++i) {
            for (int j=0; j<numQueens; ++j) {
                if (i != j && queensR[i] == queensR[j]) {
                    return false;
                }
            }
        }
        return true;
    }

    // helper method for method queensAreSafe that checks if the queens are safe vertically
    private static boolean checkVerticals(char[][] board, int numQueens, int[] queensR, int[] queensC){
        // check if any of the columns are the same (THAT WOULD BE UNSAFE)
        for(int i=0; i<numQueens; ++i) {
            for (int j=0; j<numQueens; ++j) {
                if (i != j && queensC[i] == queensC[j]) {
                    return false;
                }
            }
        }
        return true;
    }

    // helper method for method queensAreSafe that checks if the queens are safe for bottom left to top right diagonals
    private static boolean checkDiagonals1(char[][] board, int numQueens, int[] queensR, int[] queensC){
        // check if row1-row2 = col1-col2 (THAT WOULD BE UNSAFE)
        for(int i=0; i<numQueens; ++i){
            for(int j=0; j<numQueens; ++j){
                if(i != j && queensR[i]-queensR[j] == queensC[i]-queensC[j]){
                    return false;
                }
            }
        }
        return true;
    }

    // helper method for method queensAreSafe that checks if the queens are safe for bottom right to top left diagonals
    private static boolean checkDiagonals2(char[][] board, int numQueens, int[] queensR, int[] queensC){
        // check if row1-row2 = col1-col2 (THAT WOULD BE UNSAFE)
        for(int i=0; i<numQueens; ++i){
            for(int j=0; j<numQueens; ++j){
                if(i != j && queensR[i]+queensC[i] == queensR[j]+queensC[j]){
                    return false;
                }
            }
        }
        return true;
    }


    /**
     * Given a 2D array of ints return the value of the
     * most valuable contiguous sub rectangle in the 2D array.
     * The sub rectangle must be at least 1 by 1. 
     * <p>pre: <tt>mat != null, mat.length > 0, mat[0].length > 0,
     * mat</tt> is a rectangular matrix.
     * <p>post: return the value of the most valuable contiguous sub rectangle
     * in <tt>city</tt>.<br>
     * @param city The 2D array of ints representing the value of
     * each block in a portion of a city.
     * @return return the value of the most valuable contiguous sub rectangle
     * in <tt>city</tt>.
     */
    public static int getValueOfMostValuablePlot(int[][] city) {
        // check preconditions
        if (city == null || city.length == 0 || city[0].length == 0
                || !isRectangular(city) ) {
            throw new IllegalArgumentException("Violation of precondition: " +
                    "getValueOfMostValuablePlot. The parameter may not be null," +
                    " must value at least one row and at least" +
                    " one column, and must be rectangular.");
        }

        // greatest value
        int mostValue = Integer.MIN_VALUE/2;

        // loop through every possible rectangle
        // first go through the sizes starting from 1x1, 1x2, etc. until rxc
        for(int numRows=1; numRows<=city.length; ++numRows){
            for(int numCols=1; numCols <=city[0].length; ++numCols){

                // next go through all of the starting places
                for(int startR=0; startR<city.length-numRows+1; ++startR){
                    for(int startC=0; startC<city[0].length-numCols+1; ++startC){

                        // value of this specific plot
                        int value = 0;

                        // sum the values within the plot
                        for(int r=startR; r<startR+numRows; ++r){
                            for(int c=startC; c<startC+numCols; ++c){
                                value += city[r][c];
                            }
                        }

                        // if the new value is greater, then replace
                        if(value > mostValue){
                            mostValue = value;
                        }
                    }
                }
            }
        }
        return mostValue;
    }


    // !!!!! ***** !!!!! ***** !!!!! ****** !!!!! ****** !!!!! ****** !!!!!!
    // CS314 STUDENTS: Put your birthday problem experiment code here:

    public static void birthdayExperiment(){
        // First experiment
        // total pairs var
        int total1 = 0;
        for(int i=0; i<1000000; ++i){
            total1 += sharedBirthdays(182, 365);
        }
        // I commented the print out, but this is how I got my answer
        //System.out.println(total1/1000000);

        // my prediction is 30 people for how many people until 50% chance that at least 2 people share a birthday
        // Second experiment
        for(int numPeople=2; numPeople<=100; ++numPeople){
            // count how many have >= 1 pairs
            int total2 = 0;
            for(int i=0; i<50000; ++i){
                if(sharedBirthdays(numPeople, 365) > 0){
                    ++total2;
                }
            }
            // I commented the print out, but this is how I got my table
            //System.out.println("Num poeple: " + numPeople + ", number of experiments with one or more shared birthday: " + total2 + ", percentage: " + (double)total2/(double)500);
        }
    }


    /*
     * pre: arrayOfStrings != null
     * post: return true if at least one element in arrayOfStrings is
     * not null, otherwise return false.
     */
    private static boolean atLeastOneNonNull(String[] arrayOfStrings) {
        // check precondition
        if (arrayOfStrings == null) {
            throw new IllegalArgumentException("Violation of precondition: " +
                    "atLeastOneNonNull. parameter may not equal null.");
        }
        boolean foundNonNull = false;
        int i = 0;
        while( !foundNonNull && i < arrayOfStrings.length ) {
            foundNonNull = arrayOfStrings[i] != null;
            i++;
        }
        return foundNonNull;
    }


    /*
     * pre: mat != null
     * post: return true if mat is a square matrix, false otherwise
     */
    private static boolean isSquare(char[][] mat) {
        if (mat == null) {
            throw new IllegalArgumentException("Violation of precondition: " +
                    "isSquare. Parameter may not be null.");
        }
        final int numRows = mat.length;
        int row = 0;
        boolean isSquare = true;
        while (isSquare && row < numRows) {
            isSquare = ( mat[row] != null) && (mat[row].length == numRows);
            row++;
        }
        return isSquare;
    }


    /*
     * pre: mat != null, valid != null
     * post: return true if all elements in mat are one of the
     * characters in valid
     */
    private static boolean onlyContains(char[][] mat, char[] valid) {
        // check preconditions
        if (mat == null || valid == null) {
            throw new IllegalArgumentException("Violation of precondition: " +
                    "onlyContains. Parameters may not be null.");
        }
        String validChars = new String(valid);
        int row = 0;
        boolean onlyContainsValidChars = true;
        while (onlyContainsValidChars && row < mat.length) {
            int col = 0;
            while(onlyContainsValidChars && col < mat[row].length) {
                int indexOfChar = validChars.indexOf(mat[row][col]);
                onlyContainsValidChars = indexOfChar != -1;
                col++;
            }
            row++;
        }
        return onlyContainsValidChars;
    }


    /*
     * pre: mat != null, mat.length > 0
     * post: return true if mat is rectangular
     */
    private static boolean isRectangular(int[][] mat) {
        // check preconditions
        if (mat == null || mat.length == 0) {
            throw new IllegalArgumentException("Violation of precondition: " +
                    "isRectangular. Parameter may not be null and must contain" +
                    " at least one row.");
        }
        boolean correct = mat[0] != null;
        int row = 0;
        while(correct && row < mat.length) {
            correct = (mat[row] != null)
                    && (mat[row].length == mat[0].length);
            row++;
        }
        return correct;
    }

    // make constructor private so no instances of CodeCamp can not be created
    private CodeCamp() {

    }
}