import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Random;

// CodeCamp.java - CS314 Assignment 1 - Tester class

/*
 * Student information for assignment:
 * Name: Nathaniel Li
 * email address: nathaniel.li@utexas.edu
 * UTEID: nl9656
 * Section 5 digit ID: 50860
 * Grader name:
 * Number of slip days used on this assignment: 0
 */

/*
 *** EXPERIMENT ONE ***
I got an average of 45 pairs for 182 people with 365 days in a year.

 *** EXPERIMENT TWO ***
I had an initial guess of 30 people to have at least 50% chance of having at least 1 shared birthday
From my tests, you need 23 people to have an at least 50% chance of having at least 1 shared birthday

Table:

Num poeple: 2, number of experiments with one or more shared birthday: 122, percentage: 0.24
Num poeple: 3, number of experiments with one or more shared birthday: 440, percentage: 0.88
Num poeple: 4, number of experiments with one or more shared birthday: 800, percentage: 1.60
Num poeple: 5, number of experiments with one or more shared birthday: 1363, percentage: 2.73
Num poeple: 6, number of experiments with one or more shared birthday: 1968, percentage: 3.94
Num poeple: 7, number of experiments with one or more shared birthday: 2731, percentage: 5.46
Num poeple: 8, number of experiments with one or more shared birthday: 3776, percentage: 7.55
Num poeple: 9, number of experiments with one or more shared birthday: 4776, percentage: 9.55
Num poeple: 10, number of experiments with one or more shared birthday: 5775, percentage: 11.55
Num poeple: 11, number of experiments with one or more shared birthday: 7037, percentage: 14.07
Num poeple: 12, number of experiments with one or more shared birthday: 8257, percentage: 16.51
Num poeple: 13, number of experiments with one or more shared birthday: 9745, percentage: 19.49
Num poeple: 14, number of experiments with one or more shared birthday: 11173, percentage: 22.35
Num poeple: 15, number of experiments with one or more shared birthday: 12541, percentage: 25.08
Num poeple: 16, number of experiments with one or more shared birthday: 14388, percentage: 28.78
Num poeple: 17, number of experiments with one or more shared birthday: 15952, percentage: 31.90
Num poeple: 18, number of experiments with one or more shared birthday: 17379, percentage: 34.76
Num poeple: 19, number of experiments with one or more shared birthday: 18794, percentage: 37.59
Num poeple: 20, number of experiments with one or more shared birthday: 20537, percentage: 41.07
Num poeple: 21, number of experiments with one or more shared birthday: 22099, percentage: 44.20
Num poeple: 22, number of experiments with one or more shared birthday: 23761, percentage: 47.52
Num poeple: 23, number of experiments with one or more shared birthday: 25471, percentage: 50.94
Num poeple: 24, number of experiments with one or more shared birthday: 26922, percentage: 53.84
Num poeple: 25, number of experiments with one or more shared birthday: 28474, percentage: 56.95
Num poeple: 26, number of experiments with one or more shared birthday: 29937, percentage: 59.87
Num poeple: 27, number of experiments with one or more shared birthday: 31239, percentage: 62.48
Num poeple: 28, number of experiments with one or more shared birthday: 32701, percentage: 65.40
Num poeple: 29, number of experiments with one or more shared birthday: 34130, percentage: 68.26
Num poeple: 30, number of experiments with one or more shared birthday: 35476, percentage: 70.95
Num poeple: 31, number of experiments with one or more shared birthday: 36609, percentage: 73.22
Num poeple: 32, number of experiments with one or more shared birthday: 37586, percentage: 75.17
Num poeple: 33, number of experiments with one or more shared birthday: 38750, percentage: 77.50
Num poeple: 34, number of experiments with one or more shared birthday: 39594, percentage: 79.19
Num poeple: 35, number of experiments with one or more shared birthday: 40977, percentage: 81.95
Num poeple: 36, number of experiments with one or more shared birthday: 41686, percentage: 83.37
Num poeple: 37, number of experiments with one or more shared birthday: 42574, percentage: 85.15
Num poeple: 38, number of experiments with one or more shared birthday: 43196, percentage: 86.39
Num poeple: 39, number of experiments with one or more shared birthday: 43923, percentage: 87.85
Num poeple: 40, number of experiments with one or more shared birthday: 44476, percentage: 88.95
Num poeple: 41, number of experiments with one or more shared birthday: 45137, percentage: 90.27
Num poeple: 42, number of experiments with one or more shared birthday: 45753, percentage: 91.51
Num poeple: 43, number of experiments with one or more shared birthday: 46145, percentage: 92.29
Num poeple: 44, number of experiments with one or more shared birthday: 46659, percentage: 93.32
Num poeple: 45, number of experiments with one or more shared birthday: 47106, percentage: 94.21
Num poeple: 46, number of experiments with one or more shared birthday: 47404, percentage: 94.81
Num poeple: 47, number of experiments with one or more shared birthday: 47733, percentage: 95.47
Num poeple: 48, number of experiments with one or more shared birthday: 47994, percentage: 95.99
Num poeple: 49, number of experiments with one or more shared birthday: 48323, percentage: 96.65
Num poeple: 50, number of experiments with one or more shared birthday: 48520, percentage: 97.04
Num poeple: 51, number of experiments with one or more shared birthday: 48734, percentage: 97.47
Num poeple: 52, number of experiments with one or more shared birthday: 48863, percentage: 97.73
Num poeple: 53, number of experiments with one or more shared birthday: 49040, percentage: 98.08
Num poeple: 54, number of experiments with one or more shared birthday: 49248, percentage: 98.50
Num poeple: 55, number of experiments with one or more shared birthday: 49303, percentage: 98.61
Num poeple: 56, number of experiments with one or more shared birthday: 49401, percentage: 98.80
Num poeple: 57, number of experiments with one or more shared birthday: 49519, percentage: 99.04
Num poeple: 58, number of experiments with one or more shared birthday: 49548, percentage: 99.10
Num poeple: 59, number of experiments with one or more shared birthday: 49624, percentage: 99.25
Num poeple: 60, number of experiments with one or more shared birthday: 49698, percentage: 99.40
Num poeple: 61, number of experiments with one or more shared birthday: 49753, percentage: 99.51
Num poeple: 62, number of experiments with one or more shared birthday: 49802, percentage: 99.60
Num poeple: 63, number of experiments with one or more shared birthday: 49835, percentage: 99.67
Num poeple: 64, number of experiments with one or more shared birthday: 49881, percentage: 99.76
Num poeple: 65, number of experiments with one or more shared birthday: 49887, percentage: 99.77
Num poeple: 66, number of experiments with one or more shared birthday: 49881, percentage: 99.76
Num poeple: 67, number of experiments with one or more shared birthday: 49925, percentage: 99.85
Num poeple: 68, number of experiments with one or more shared birthday: 49940, percentage: 99.88
Num poeple: 69, number of experiments with one or more shared birthday: 49944, percentage: 99.89
Num poeple: 70, number of experiments with one or more shared birthday: 49952, percentage: 99.90
Num poeple: 71, number of experiments with one or more shared birthday: 49978, percentage: 99.96
Num poeple: 72, number of experiments with one or more shared birthday: 49971, percentage: 99.94
Num poeple: 73, number of experiments with one or more shared birthday: 49972, percentage: 99.94
Num poeple: 74, number of experiments with one or more shared birthday: 49983, percentage: 99.97
Num poeple: 75, number of experiments with one or more shared birthday: 49988, percentage: 99.98
Num poeple: 76, number of experiments with one or more shared birthday: 49986, percentage: 99.97
Num poeple: 77, number of experiments with one or more shared birthday: 49991, percentage: 99.98
Num poeple: 78, number of experiments with one or more shared birthday: 49992, percentage: 99.98
Num poeple: 79, number of experiments with one or more shared birthday: 49994, percentage: 99.99
Num poeple: 80, number of experiments with one or more shared birthday: 49996, percentage: 99.99
Num poeple: 81, number of experiments with one or more shared birthday: 49999, percentage: 100.00
Num poeple: 82, number of experiments with one or more shared birthday: 49996, percentage: 99.99
Num poeple: 83, number of experiments with one or more shared birthday: 49999, percentage: 100.00
Num poeple: 84, number of experiments with one or more shared birthday: 49999, percentage: 100.00
Num poeple: 85, number of experiments with one or more shared birthday: 49998, percentage: 100.00
Num poeple: 86, number of experiments with one or more shared birthday: 49999, percentage: 100.00
Num poeple: 87, number of experiments with one or more shared birthday: 50000, percentage: 100.00
Num poeple: 88, number of experiments with one or more shared birthday: 50000, percentage: 100.00
Num poeple: 89, number of experiments with one or more shared birthday: 50000, percentage: 100.00
Num poeple: 90, number of experiments with one or more shared birthday: 50000, percentage: 100.00
Num poeple: 91, number of experiments with one or more shared birthday: 50000, percentage: 100.00
Num poeple: 92, number of experiments with one or more shared birthday: 49999, percentage: 100.00
Num poeple: 93, number of experiments with one or more shared birthday: 49999, percentage: 100.00
Num poeple: 94, number of experiments with one or more shared birthday: 50000, percentage: 100.00
Num poeple: 95, number of experiments with one or more shared birthday: 50000, percentage: 100.00
Num poeple: 96, number of experiments with one or more shared birthday: 50000, percentage: 100.00
Num poeple: 97, number of experiments with one or more shared birthday: 50000, percentage: 100.00
Num poeple: 98, number of experiments with one or more shared birthday: 50000, percentage: 100.00
Num poeple: 99, number of experiments with one or more shared birthday: 50000, percentage: 100.00
Num poeple: 100, number of experiments with one or more shared birthday: 50000, percentage: 100.00
 */

public class CodeCampTester {

    public static void main(String[] args) {
        final String newline = System.getProperty("line.separator");

        // test 1, hamming distance
        int[] h1 = { 0, 1, 2, 3 };
        int[] h2 = { 0, 1, 2, 3 };
        int expected = 0;
        int actual = CodeCamp.hammingDistance(h1, h2);
        System.out.println("Test 1 hamming distance: expected value: " + expected
                + ", actual value: " + actual);
        if (expected == actual) {
            System.out.println(" passed test 1, hamming distance");
        } else {
            System.out.println(" ***** FAILED ***** test 1, hamming distance");
        }

        // test 2, hamming distance
        h1 = new int[] { 5, 4, 3, 2, 1 };
        h2 = new int[] { 5, 3, 2, 4, 1 };
        expected = 3;
        actual = CodeCamp.hammingDistance(h1, h2);
        System.out.println(newline + "Test 2 hamming distance: expected value: " + expected
                + ", actual value: " + actual);
        if (expected == actual) {
            System.out.println(" passed test 2, hamming distance");
        } else {
            System.out.println(" ***** FAILED ***** test 2, hamming distance");
        }

        // test 3, isPermutation
        int[] a = { 0, 1, 2, 3 };
        int[] b = { 1, 2, 3, 0 };
        boolean expectedBool = true;
        boolean actualBool = CodeCamp.isPermutation(a, b);
        System.out.println(newline + "Test 3 isPermutation: expected value: " + expectedBool
                + ", actual value: " + actualBool);
        if (expectedBool == actualBool) {
            System.out.println(" passed test 3, isPermutation");
        } else {
            System.out.println(" ***** FAILED ***** test 3, isPermutation");
        }

        // test 4, is Permutation
        int[] c = { 1, 2, 3, 4, 6 };
        int[] d = { 1, 3, 4, 5, 6 };
        expectedBool = false;
        actualBool = CodeCamp.isPermutation(c, d);
        System.out.println(newline + "Test 4 isPermutation: expected value: " + expectedBool
                + ", actual value: " + actualBool);
        if (expectedBool == actualBool) {
            System.out.println(" passed test 4, isPermutation");
        } else {
            System.out.println(" ***** FAILED ***** test 4, isPermutation");
        }

        // test 5, mostVowels
        String[] arrayOfStrings = { "1234567890abcdefghijklmnopqrstuvwxyz", "aaeeiioouu" };
        int expectedResult = 1;
        int actualResult = CodeCamp.mostVowels(arrayOfStrings);
        System.out.println(newline + "Test 5 mostVowels: expected result: " + expectedResult
                + ", actual result: " + actualResult);
        if (actualResult == expectedResult) {
            System.out.println("passed test 5, mostVowels");
        } else {
            System.out.println("***** FAILED ***** test 5, mostVowels");
        }

        // test 6, mostVowels
        arrayOfStrings = new String[] { "Hello", "Computer", "Science", "314", "Class" };
        expectedResult = 1;
        actualResult = CodeCamp.mostVowels(arrayOfStrings);
        System.out.println(newline + "Test 6 mostVowels: expected result: " + expectedResult
                + ", actual result: " + actualResult);
        if (actualResult == expectedResult) {
            System.out.println("passed test 6, mostVowels");
        } else {
            System.out.println("***** FAILED ***** test 6, mostVowels");
        }

        // test 7, sharedBirthdays
        int pairs = CodeCamp.sharedBirthdays(1, 1);
        int expectedShared = 0;
        System.out.println(newline + "Test 7 shared birthdays: expected: " + expectedShared + ",  actual: " + pairs);
        if (pairs == expectedShared) {
            System.out.println("passed test 7, shared birthdays");
        } else {
            System.out.println("***** FAILED ***** test 7, shared birthdays");
        }

        // test 8, sharedBirthdays
        pairs = CodeCamp.sharedBirthdays(10, 1);
        expectedShared = 45;
        System.out.println(newline + "Test 8 shared birthdays: expected: "
                + expectedShared + "actual: " + pairs);
        if (pairs > 0) {
            System.out.println("passed test 8, shared birthdays");
        } else {
            System.out.println("***** FAILED ***** test 8, shared birthdays");
        }

        // test 9, queensAreASafe
        char[][] board = { { 'q', '.', '.' },
                { '.', 'q', '.' },
                { '.', '.', 'q' } };

        expectedBool = false;
        actualBool = CodeCamp.queensAreSafe(board);
        System.out.println(newline + "Test 9 queensAreSafe: expected value: " + expectedBool
                + ", actual value: " + actualBool);
        if (expectedBool == actualBool) {
            System.out.println(" passed test 9, queensAreSafe");
        } else {
            System.out.println(" ***** FAILED ***** test 9, queensAreSafe");
        }

        // test 10, queensAreASafe
        board = new char[][] { { '.', 'q', '.', '.' },
                { '.', '.', '.', 'q' },
                { 'q', '.', '.', '.' },
                { '.', '.', 'q', '.' } };
        expectedBool = true;
        actualBool = CodeCamp.queensAreSafe(board);
        System.out.println(newline + "Test 10 queensAreSafe: expected value: " + expectedBool
                + ", actual value: " + actualBool);
        if (expectedBool == actualBool) {
            System.out.println(" passed test 10, queensAreSafe");
        } else {
            System.out.println(" ***** FAILED ***** test 10, queensAreSafe");
        }

        // test 11, getValueOfMostValuablePlot
        int[][] city = { { 4, -3, 2, -1 },
                { 1, -2, 3, -4, },
                { -4, 3, -2, 1, },
                { -1, 2, -3, 4, }};

        expected = 5;
        actual = CodeCamp.getValueOfMostValuablePlot(city);
        System.out.println(newline + "Test 11 getValueOfMostValuablePlot: expected value: "
                + expected + ", actual value: " + actual);
        if (expected == actual) {
            System.out.println(" passed test 11, getValueOfMostValuablePlot");
        } else {
            System.out.println(" ***** FAILED ***** test 11, getValueOfMostValuablePlot");
        }

        // test 12, getValueOfMostValuablePlot
        city = new int[][] { { 3, 2, 1, 0, -1, -2, -3 } };
        expected = 6;
        actual = CodeCamp.getValueOfMostValuablePlot(city);
        System.out.println(newline + "Test 12 getValueOfMostValuablePlot: expected value: "
                + expected + ", actual value: " + actual);
        if (expected == actual) {
            System.out.println(" passed test 12, getValueOfMostValuablePlot");
        } else {
            System.out.println(" ***** FAILED ***** test 12, getValueOfMostValuablePlot");
        }

    } // end of main method

    // pre: list != null
    private static int[] intListToArray(List<Integer> list) {
        if (list == null) {
            throw new IllegalArgumentException("list parameter may not be null.");
        }
        int[] result = new int[list.size()];
        int arrayIndex = 0;
        for (int x : list) {
            result[arrayIndex++] = x;
        }
        return result;
    }
}