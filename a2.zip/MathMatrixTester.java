import java.util.Random;

/*  Student information for assignment:
 *
 *  UTEID: nl9656
 *  email address: nathaniel.li@utexas.edu
 *  Grader name:
 *  Number of slip days I am using: 1
 */



/* CS314 Students. Put your experiment results and
 * answers to questions here.
 *
 * EXPERIMENT 1:
 * N: 550x550       1.08s
 * 2N: 1100x1100    3.48s
 * 4N: 2200x2200    11.85s
 *
 * EXPERIMENT 2:
 * N: 190x190 1.16
 * 2N: 380x380 13.11
 * 4N: 760x760 122.78
 *
 * 1.) I would expect the experiment to last around 40 seconds
 * 2.) It is O(N^2) and yes the time affirms this
 * 3.) I would expect the experiment to last around 10,000 seconds
 * 4.) It is O(N^3) and I can't really tell if the time affirms... maybe with more tests
 * 5.) Around 13,000 by 13,000 before it runs out of memory. So 4*13k*13k is barely less than 7M, so I'd guess 8 megabytes.
 */

/**
 * A class to run tests on the MathMatrix class
 */
public class MathMatrixTester {

    /**
     * main method that runs simple test on the MathMatrix class
     *
     * @param args not used
     */
    public static void main(String[] args) {
        int[][] check;

        //test 1, specify size and values constructor
        MathMatrix mat1 = new MathMatrix(2, 2, 1);
        check = new int[][] {{1, 1}, {1, 1}};
        printTestResult( get2DArray(mat1), check, 1, "Constructor specified");

        //test 2, specify size and values constructor
        MathMatrix mat2 = new MathMatrix(1, 1, 0);
        check = new int[][] {{0}};
        printTestResult( get2DArray(mat2), check, 2, "Constructor specified");


        //test 3, 4, copy constructor
        MathMatrix copy = new MathMatrix(check);
        printTestResult( get2DArray(copy), check, 3, "Constructor copied");

        check = new int[][] {{0, 0}, {0, 0}};
        copy = new MathMatrix(check);
        printTestResult( get2DArray(copy), check, 4, "Constructor copied");

        //tests 5, 6, addition
        mat2 = new MathMatrix(2,2, 2);
        MathMatrix mat3 = mat1.add(mat2);
        check = new int[][] { {3, 3}, {3, 3} };
        printTestResult( get2DArray(mat3), check, 5, "add method");
        MathMatrix mat4 = mat3.add(mat3);
        check = new int[][] { {6, 6}, {6, 6} };
        printTestResult( get2DArray(mat4), check, 6, "add method");

        //tests 7, 8, multiplication
        mat3 = mat2.multiply(mat1);
        check = new int[][] { {4, 4}, {4, 4} };
        printTestResult( get2DArray(mat3), check, 7, "multiply method");
        mat4 = mat1.multiply(mat3);
        check = new int[][] { {8, 8}, {8, 8} };
        printTestResult( get2DArray(mat4), check, 8, "multiply method");

        //test 9, 10, toString()
        String expected = "| 1 1|\n| 1 1|\n";
        if (mat1.toString().equals( expected )) {
            System.out.println("passed test 9, toString method.");
        } else {
            System.out.println("failed test 9, toString method.");
        }
        expected = "| 4 4|\n| 4 4|\n";
        if (mat3.toString().equals( expected )) {
            System.out.println("passed test 10, toString method.");
        } else {
            System.out.println("failed test 10, toString method.");
        }

        //test 11 upperTriangular
        int[][] data = new int[][] {{3, 2, 1, 0}, {0, 1, 2, 3}, {0, 0, -2, -1}, {0, 0, 0, -3}};
        mat1 = new MathMatrix(data);
        if (mat1.isUpperTriangular()) {
            System.out.println("Passed test 11, upperTriangular method.");
        } else {
            System.out.println("Failed test 11, upperTriangular method.");
        }

        //test 12 upperTriangular
        data = new int[][] {{3, 2, 1, 0}, {0, 1, 2, 3}, {0, 0, -2, -1}, {5, 0, 0, -3}};
        mat1 = new MathMatrix(data);
        if (!mat1.isUpperTriangular()) {
            System.out.println("Passed test 12, upperTriangular method.");
        } else {
            System.out.println("Failed test 12, upperTriangular method.");
        }

        //tests 13,14 getNumRows
        if (mat1.getNumRows() == 4){
            System.out.println("Passed test 13, getNumRows method.");
        } else {
            System.out.println("Failed test 13, getNumRows method.");
        }
        if (mat2.getNumRows() == 2){
            System.out.println("Passed test 14, getNumRows method.");
        } else {
            System.out.println("Failed test 14, getNumRows method.");
        }

        //tests 15,16 getNumColumns
        if (mat1.getNumColumns() == 4){
            System.out.println("Passed test 15, getNumColumns method.");
        } else {
            System.out.println("Failed test 15, getNumColumns method.");
        }
        if (mat2.getNumColumns() == 2){
            System.out.println("Passed test 16, getNumColumns method.");
        } else {
            System.out.println("Failed test 16, getNumColumns method.");
        }

        //tests 17,18 getVal
        if (mat1.getVal(1, 1) == 1){
            System.out.println("Passed test 17, getVal method.");
        } else {
            System.out.println("Failed test 17, getVal method.");
        }
        if (mat4.getVal(0, 0) == 8){
            System.out.println("Passed test 18, getVal method.");
        } else {
            System.out.println("Failed test 18, getVal method.");
        }

        //tests 19, 20, subtraction
        mat2 = mat4.subtract(mat3);
        check = new int[][] { {4, 4}, {4, 4} };
        printTestResult( get2DArray(mat2), check, 19, "subtraction method");
        mat4 = mat2.subtract(mat3);
        check = new int[][] { {0, 0}, {0, 0} };
        printTestResult( get2DArray(mat4), check, 20, "subtraction method");

        //tests 21, 22, getScaled
        mat4 = mat2.getScaledMatrix(1);
        check = new int[][] { {4, 4}, {4, 4} };
        printTestResult( get2DArray(mat4), check, 21, "subtraction method");
        mat3 = mat4.getScaledMatrix(2);
        check = new int[][] { {8, 8}, {8, 8} };
        printTestResult( get2DArray(mat3), check, 22, "subtraction method");

        //tests 23, 24, getTransposed
        mat4 = mat2.getTranspose();
        check = new int[][] { {4, 4}, {4, 4} };
        printTestResult( get2DArray(mat4), check, 23, "getTransposed method");
        mat1 = mat3.getTranspose();
        check = new int[][] { {8, 8}, {8, 8} };
        printTestResult( get2DArray(mat1), check, 24, "getTransposed method");

        //tests 25, 26, equals
        if (mat4.equals(mat2)){
            System.out.println("Passed test 25, getVal method.");
        } else {
            System.out.println("Failed test 25, getVal method.");
        }
        if (!mat4.equals(mat1)){
            System.out.println("Passed test 26, getVal method.");
        } else {
            System.out.println("Failed test 26, getVal method.");
        }

    }

    // method that sums elements of mat, may overflow int!
    // pre: mat != null
    private static int sumVals(MathMatrix mat) {
        if (mat == null) {
            throw new IllegalArgumentException("mat may not be null");
        } 
        int result = 0;
        final int ROWS =  mat.getNumRows();
        final int COLS = mat.getNumColumns();
        for (int r = 0; r < ROWS; r++) {
            for (int c = 0; c < COLS; c++) {
                result += mat.getVal(r, c); // likely to overflow, but can still do simple check
            }
        }
        return result;
    }

    // create a matrix with random values
    // pre: rows > 0, cols > 0, randNumGen != null
    public static MathMatrix createMat(Random randNumGen, int rows,
            int cols, final int LIMIT) {

        if (randNumGen == null) {
            throw new IllegalArgumentException("randomNumGen variable may no be null");
        } else if(rows <= 0 || cols <= 0) {
            throw new IllegalArgumentException("rows and columns must be greater than 0. " +
                    "rows: " + rows + ", cols: " + cols);
        }

        int[][] temp = new int[rows][cols];
        final int SUB = LIMIT / 4;
        for(int r = 0; r < rows; r++) {
            for(int c = 0; c < cols; c++) {
                temp[r][c] = randNumGen.nextInt(LIMIT) - SUB;
            }
        }

        return new MathMatrix(temp);
    }

    private static void printTestResult(int[][] data1, int[][] data2, int testNum, String testingWhat) {
        System.out.print("Test number " + testNum + " tests the " + testingWhat +". The test ");
        String result = equals(data1, data2) ? "passed" : "failed";
        System.out.println(result);
    }

    // pre: m != null, m is at least 1 by 1 in size
    // return a 2d array of ints the same size as m and with 
    // the same elements
    private static int[][] get2DArray(MathMatrix m) {
        //check precondition
        if  ((m == null) || (m.getNumRows() == 0) 
                || (m.getNumColumns() == 0)) {
            throw new IllegalArgumentException("Violation of precondition: get2DArray");
        }

        int[][] result = new int[m.getNumRows()][m.getNumColumns()];
        for(int r = 0; r < result.length; r++) {
            for(int c = 0; c < result[0].length; c++) {
                result[r][c] = m.getVal(r,c);
            }
        }
        return result;
    }

    // pre: data1 != null, data2 != null, data1 and data2 are at least 1 by 1 matrices
    //      data1 and data2 are rectangular matrices
    // post: return true if data1 and data2 are the same size and all elements are
    //      the same
    private static boolean equals(int[][] data1, int[][] data2) {
        //check precondition
        if((data1 == null) || (data1.length == 0) 
                || (data1[0].length == 0) || !rectangularMatrix(data1)
                ||  (data2 == null) || (data2.length == 0)
                || (data2[0].length == 0) || !rectangularMatrix(data2)) {
            throw new IllegalArgumentException( "Violation of precondition: equals check on 2d arrays of ints");
        }
        boolean result = (data1.length == data2.length) && (data1[0].length == data2[0].length);
        int row = 0;
        while (result && row < data1.length) {
            int col = 0;
            while (result && col < data1[0].length) {
                result = (data1[row][col] == data2[row][col]);
                col++;
            }
            row++;
        }

        return result;
    }


    // method to ensure mat is rectangular
    // pre: mat != null, mat is at least 1 by 1
    private static boolean rectangularMatrix( int[][] mat ) {
        if (mat == null || mat.length == 0 || mat[0].length == 0) {
            throw new IllegalArgumentException("Violation of precondition: "
                    + " Parameter mat may not be null" 
                    + " and must be at least 1 by 1");
        }
        return MathMatrix.rectangularMatrix(mat);
    }
}

    /*
    Stopwatch st = new Stopwatch();
        st.start();
                int[][] data1 = new int[14000][760];
                data1[2][3] = 1;
                mat1 = new MathMatrix(data1);
                int[][] data2 = new int[14000][760];
                data2[5][3] = 1;
                mat2 = new MathMatrix(data2);

                for(int i=0; i<100; ++i){
        mat3 = mat1.multiply(mat2);
        }
        st.stop();
        System.out.println(st.time());
//*/