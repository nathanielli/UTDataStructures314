import java.util.Arrays;
//MathMatrix.java - CS314 Assignment 2

/*  Student information for assignment:
*
*  On my honor, <NAME>, this programming assignment is my own work
*  and I have not provided this code to any other student.
*
*  UTEID: nl9656
*  email address: nathaniel.li@utexas.edu
*  Unique section number: 50860
*  Number of slip days I am using: 1
*/

/**
 * A class that models systems of linear equations (Math Matrices)
 * as used in linear algebra.
 */
public class MathMatrix {
    
    // instance variable
    private int[][] m;
    /**
     * create a MathMatrix with cells equal to the values in mat.
     * A "deep" copy of mat is made.
     * Changes to mat after this constructor do not affect this
     * Matrix and changes to this MathMatrix do not affect mat
     * @param  mat  mat !=null, mat.length > 0, mat[0].length > 0,
     * mat is a rectangular matrix
     */
    public MathMatrix(int[][] mat) {
        // check conditions
        if (mat == null || mat.length <= 0 || mat[0].length <= 0) {
            throw new IllegalArgumentException("Violation of precondition: mat != null, mat.length > 0, mat[0].length > 0");
        }

        m = new int[mat.length][mat[0].length];
        for(int r=0; r<mat.length; ++r){
            for(int c=0; c<mat[0].length; ++c){
                m[r][c] = mat[r][c];
            }
        }
    }


    /**
     * create a MathMatrix of the specified size with all cells set to the intialValue.
     * <br>pre: numRows > 0, numCols > 0
     * <br>post: create a matrix with numRows rows and numCols columns. 
     * All elements of this matrix equal initialVal.
     * In other words after this method has been called getVal(r,c) = initialVal 
     * for all valid r and c.
     * @param numRows numRows > 0
     * @param numCols numCols > 0
     * @param initialVal all cells of this Matrix are set to initialVal
     */
    public MathMatrix(int numRows, int numCols, int initialVal) {
        // check conditions
        if (numRows <= 0 || numCols <= 0) {
            throw new IllegalArgumentException("Violation of precondition: numRows > 0, numCols > 0");
        }

        m = new int[numRows][numCols];
        for(int r=0; r<numRows; ++r){
            for(int c=0; c<numCols; ++c){
                m[r][c] = initialVal;
            }
        }
    }

    /**
     * Get the number of rows.
     * @return the number of rows in this MathMatrix
     */
    public int getNumRows() {
        return m.length;
    }


    /**
     * Get the number of columns.
     * @return the number of columns in this MathMatrix
     */
    public int getNumColumns(){
        return m[0].length;
    }


    /**
     * get the value of a cell in this MathMatrix.
     * <br>pre: row  0 <= row < getNumRows(), col  0 <= col < getNumColumns()
     * @param  row  0 <= row < getNumRows()
     * @param  col  0 <= col < getNumColumns()
     * @return the value at the specified position
     */
    public int getVal(int row, int col) {
        // check conditions
        if (row < 0 || col < 0) {
            throw new IllegalArgumentException("Violation of precondition: numRows > 0, numCols > 0");
        }
        return m[row][col];
    }


    /**
     * implements MathMatrix addition, (this MathMatrix) + rightHandSide.
     * <br>pre: rightHandSide.getNumRows() = getNumRows(), rightHandSide.numCols() = getNumColumns()
     * <br>post: This method does not alter the calling object or rightHandSide
     * @param rightHandSide rightHandSide.getNumRows() = getNumRows(), rightHandSide.numCols() = getNumColumns()
     * @return a new MathMatrix that is the result of adding this Matrix to rightHandSide.
     * The number of rows in the returned Matrix is equal to the number of rows in this MathMatrix.
     * The number of columns in the returned Matrix is equal to the number of columns in this MathMatrix.
     */
    public MathMatrix add(MathMatrix rightHandSide) {
        // check conditions
        if (rightHandSide.getNumRows() != getNumRows() || rightHandSide.getNumColumns() != getNumColumns()) {
            throw new IllegalArgumentException("Violation of precondition: rightHandSide.getNumRows() = getNumRows(), rightHandSide.numCols() = getNumColumns()");
        }

        // make new answer mathmatrix that we return
        int[][] ans = new int[rightHandSide.getNumRows()][rightHandSide.getNumColumns()];
        // sum values to array
        for(int r=0; r<rightHandSide.getNumRows(); ++r){
            for(int c=0; c<rightHandSide.getNumColumns(); ++c){
                ans[r][c] = getVal(r, c) + rightHandSide.getVal(r, c);
            }
        }

        // create MathMatrix to return
        MathMatrix answer = new MathMatrix(ans);
        return answer;
    }


    /**
     * implements MathMatrix subtraction, (this MathMatrix) - rightHandSide.
     * <br>pre: rightHandSide.getNumRows() = getNumRows(), rightHandSide.numCols() = getNumColumns()
     * <br>post: This method does not alter the calling object or rightHandSide
     * @param rightHandSide rightHandSide.getNumRows() = getNumRows(), rightHandSide.numCols() = getNumColumns()
     * @return a new MathMatrix that is the result of subtracting rightHandSide from this MathMatrix.
     * The number of rows in the returned MathMatrix is equal to the number of rows in this MathMatrix.
     * The number of columns in the returned MathMatrix is equal to the number of columns in this MathMatrix.
     */
    public MathMatrix subtract(MathMatrix rightHandSide){
        // check conditions
        if (rightHandSide.getNumRows() != getNumRows() || rightHandSide.getNumColumns() != getNumColumns()) {
            throw new IllegalArgumentException("Violation of precondition: rightHandSide.getNumRows() = getNumRows(), rightHandSide.numCols() = getNumColumns()");
        }

        // make new answer mathmatrix that we return
        int[][] ans = new int[rightHandSide.getNumRows()][rightHandSide.getNumColumns()];
        // subtract RHS values from array
        for(int r=0; r<rightHandSide.getNumRows(); ++r){
            for(int c=0; c<rightHandSide.getNumColumns(); ++c){
                ans[r][c] = getVal(r, c) - rightHandSide.getVal(r, c);
            }
        }

        // create MathMatrix to return
        MathMatrix answer = new MathMatrix(ans);
        return answer;
    }


    /**
     * implements matrix multiplication, (this MathMatrix) * rightHandSide.
     * <br>pre: rightHandSide.getNumRows() = getNumColumns()
     * <br>post: This method should not alter the calling object or rightHandSide
     * @param rightHandSide rightHandSide.getNumRows() = getNumColumns()
     * @return a new MathMatrix that is the result of multiplying this MathMatrix and rightHandSide.
     * The number of rows in the returned MathMatrix is equal to the number of rows in this MathMatrix.
     * The number of columns in the returned MathMatrix is equal to the number of columns in rightHandSide.
     */
    public MathMatrix multiply(MathMatrix rightHandSide){
        // check conditions
        if (rightHandSide.getNumRows() != getNumColumns()) {
            throw new IllegalArgumentException("Violation of precondition: rightHandSide.getNumRows() = getNumColumns(), rightHandSide.numCols() = getNumRows()");
        }

        // make new answer mathmatrix that we return
        int[][] ans = new int[getNumRows()][rightHandSide.getNumColumns()];

        // multiply values to array
        for(int row=0; row<getNumRows(); ++row){
            for(int col=0; col<rightHandSide.getNumColumns(); ++col){
                for(int i=0; i<getNumColumns(); ++i){
                    ans[row][col] += getVal(row, i) * rightHandSide.getVal(i, col);
                }
            }
        }

        // create MathMatrix to return
        MathMatrix answer = new MathMatrix(ans);
        return answer;
    } 


    /**
     * Create and return a new Matrix that is a copy
     * of this matrix, but with all values multiplied by a scale
     * value.
     * <br>pre: none
     * <br>post: returns a new Matrix with all elements in this matrix 
     * multiplied by factor. 
     * In other words after this method has been called 
     * returned_matrix.getVal(r,c) = original_matrix.getVal(r, c) * factor
     * for all valid r and c.
     * @param factor the value to multiply every cell in this Matrix by.
     * @return a MathMatrix that is a copy of this MathMatrix, but with all
     * values in the result multiplied by factor.
     */
    public MathMatrix getScaledMatrix(int factor) {
        // make new answer mathmatrix that we return
        int[][] ans = new int[getNumRows()][getNumColumns()];

        // multiply all elements by factor
        for(int r=0; r<getNumRows(); ++r){
            for(int c=0; c<getNumColumns(); ++c){
                ans[r][c] = getVal(r, c) * factor;
            }
        }

        // create MathMatrix to return
        MathMatrix answer = new MathMatrix(ans);
        return answer;
    }


    /**
     * accessor: get a transpose of this MathMatrix. 
     * This Matrix is not changed.
     * <br>pre: none
     * @return a transpose of this MathMatrix
     */
    public MathMatrix getTranspose() {
        // make new answer mathmatrix that we return
        int[][] ans = new int[getNumColumns()][getNumRows()];

        // transpose
        for(int r=0; r<getNumRows(); ++r){
            for(int c=0; c<getNumColumns(); ++c){
                ans[c][r] = getVal(r, c);
            }
        }

        // create MathMatrix to return
        MathMatrix answer = new MathMatrix(ans);
        return answer;
    }


    /**
     * override equals.
     * @return true if rightHandSide is the same size as this MathMatrix and all values in the
     * two MathMatrix objects are the same, false otherwise
     */
    public boolean equals(Object rightHandSide){
        /* CS314 Students. The following is standard equals
         * method code. We will learn about in the coming weeks.
         */
        boolean result = false;
        // We use getClass instead of instanceof because we only want a MathMatrix to equal 
        // another MathMatrix as opposed to any possible sub classes. We would
        // use instance of if we were implementing am interface and wanted to equal
        // other objects that are insances of that interfacem but not necessarily
        // MathMatrix objects.
        if( rightHandSide != null && this.getClass() == rightHandSide.getClass()){
            // rightHandSide is a non null MathMatrix
            MathMatrix otherMatrix = (MathMatrix) rightHandSide;

            // check size
            if(otherMatrix.getNumRows() == getNumRows() && otherMatrix.getNumColumns() == getNumColumns()){
                // see if any difference
                boolean same = true;
                for(int r=0; r<getNumRows(); ++r){
                    for(int c=0; c<getNumColumns(); ++c){
                        if(otherMatrix.getVal(r, c) != getVal(r, c)){
                            same = false;
                        }
                    }
                }
                result = same;
            }
        }
        return result;
    }


    /**
     * override toString.
     * @return a String with all elements of this MathMatrix. 
     * Each row is on a separate line.
     * Spacing based on longest element in this Matrix.
     */
    public String toString() {
        String ret = "";
        // find the longest element
        int longest = findLongest();

        // print
        for(int r=0; r<getNumRows(); ++r){
            ret += "|";
            for(int c=0; c<getNumColumns(); ++c){
                int length = String.valueOf(getVal(r, c)).length();
                for(int i=0; i<longest-length+1; ++i){
                    ret += " ";
                }
                ret += getVal(r, c);
            }
            ret += "|\n";
        }
        return ret;
    }

    // helper class for toString()
    private int findLongest(){
        int longest = 0;
        for(int r=0; r<getNumRows(); ++r){
            for(int c=0; c<getNumColumns(); ++c){
                int length = String.valueOf(getVal(r, c)).length();
                if(length > longest){
                    longest = length;
                }
            }
        }
        return longest;
    }



    /**
     * Return true if this MathMatrix is upper triangular. To
     * be upper triangular all elements below the main 
     * diagonal must be 0.<br>
     * pre: this is a square matrix. getNumRows() == getNumColumns()  
     * @return <tt>true</tt> if this MathMatrix is upper triangular,
     * <tt>false</tt> otherwise. 
     */
    public boolean isUpperTriangular(){
        // check conditions
        if (getNumRows() != getNumColumns()) {
            throw new IllegalArgumentException("Violation of precondition: getNumRows() == getNumColumns");
        }

        // make boolean to return
        boolean answer = true;

        // check
        for(int r=0; r<getNumRows(); ++r){
            for(int c=0; c<getNumColumns(); ++c){
                if(c<r && c!=0){
                    answer = false;
                }
            }
        }
        return answer;
    }

    // method to ensure mat is rectangular. It is public so that
    // tester classes can use it. 
    // pre: mat != null, mat has at least one row
    // return true if all rows in mat have the same
    // number of columns false otherwise.
    public static boolean rectangularMatrix(int[][] mat) {
        if (mat == null || mat.length == 0) {
            throw new IllegalArgumentException("argument mat may not be null and must "
                    + " have at least one row. mat = " + Arrays.toString(mat));
        }
        boolean isRectangular = true;
        int row = 1;
        final int COLUMNS = mat[0].length;
        while (isRectangular && row < mat.length) {
            isRectangular = (mat[row].length == COLUMNS);
            row++;
        }
        return isRectangular;
    }
}
